jQuery(function($) {'use strict';

    //Initiat WOW JS
    new WOW().init();
    //smoothScroll
    //smoothScroll.init();

});