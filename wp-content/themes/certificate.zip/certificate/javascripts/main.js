$(document).ready(function() {
if($('.footable').length != 0) {

    $('.footable').footable({
    breakpoints: {
        desktop: 900,
        tablet: 700,
        phone: 480


    }
});
}

/*
alert("xx");
$("#scXrKI a img[name='psXrKIimage']").attr("src", "../images/chatnow.png");
$("#scXrKI").css("display","inline !important");
*/

//    $(".crsl").css('margin-left', ($(window).width() - 1600) / 2);
//    $(".crsl").css('margin-left', ($(document).width() - 1600) / 2);
//    $(".right:first").css('left', ($(document).width() - 90) + 'px');
//    $(".left:first").css('left', '30px');
//    $(window).resize(function() {
//        $(".crsl").css('margin-left', ($(window).width() - 1600) / 2);
//        $(".crsl").css('margin-left', ($(document).width() - 1600) / 2);
//        $(".right:first").css('left', ($(document).width() - 90) + 'px');
//        $(".left:first").css('left', '30px');
//    });


$("a[href='#topCaros']").css('line-height', $('.jumbotron').height()+"px");
    $(window).resize(function() {
        $("a[href='#topCaros']").css('line-height', $('.jumbotron').height()+"px");
    });

});
