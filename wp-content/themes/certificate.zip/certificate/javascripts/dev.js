$(document).ready(function() {
    //add seprator to footer menu
    $('.footerMenu li:not(:last)').after('<li class="sepr hidden-xs">|</li>');
    $('.checkout input.input-text,.checkout textarea.input-text').livequery(function() {
        $(this).addClass('form-control');
    });
    $('.shop_table').addClass('table').removeClass('shop_table');
    $('.input-text,.shipping_calculator select').addClass('form-control');

});