<?php
get_header();
?>
	<div class="clr"></div>
        <div class="bg vendor-bg">
        	<form method="get" action="<?php echo get_page_link(get_post_using_slug('search-exams')); ?>" onsubmit="if(this.s.value == '' || this.s.value == 'Enter Exam Code ...'){ alert('Kindly type something in Search field');return false;}">
        	
				<input name="word" type="text" placeholder="Enter Exam Code">
        	</form>
    	</div>
	</div>
    <div class="inner">
        <ol class="breadcrumb">
            <li><a href="<?php echo home_url(); ?>">Home</a></li>
            <li class="del"></li>
            <li class="active">Search results for "<?php echo $_GET['s']; ?>"</li>
        </ol>
    </div>
    <div class="clr"></div>
    <?php if (have_posts()): ?>
    	<div class="updated-exams">
			<div class="exams-header">
				<div class="inner">
					<h3>Updated <?php echo $topCat->name; ?> Exams</h3>
				</div>
				<div class="clr"></div>
			</div>
			<div class="buttons">
				<div class="inner">
					<ul>
			        <?php while (have_posts()):the_post(); ?>
			        	<li><a href="<?php the_permalink(); ?>"><?php the_title(); ?></br><span><?php echo get_the_date('M d, Y'); ?></span></a></li>
			        	<? /*
			            <div class="col-lg-2 col-md-3 col-sm-4 col-xs-6">
			                <div class="flip">
			                    <div class="flip-front">
			                        <span class="fa fa-file-text-o"></span>
			                        <br>
			                        <span><?php the_title(); ?></span>
			                        <br>
			                        <?php echo get_the_date('M d, Y'); ?>
			                        <br>
			                        <em><?php echo get_post_meta(get_the_ID(), 'exam_full_name', TRUE); ?></em>
			                    </div>
			                    <div class="flip-back">
			                        <a href="<?php the_permalink(); ?>" class="info">
			                            <span class="glyphicon glyphicon-shopping-cart"></span>
			                            <br>
			                            Add To Cart
			                        </a>
			                    </div>
			                </div>
			            </div>
			            */
			            ?>
			        <?php endwhile; ?>
					</ul>
				</div>
				<div class="clr"></div>
			</div>
		</div>
		<div class="clr"></div>
        <?php
        if (function_exists('wp_pagenavi'))
            wp_pagenavi();
        wp_reset_query();
    else:
        ?>
        <div class="alert alert-danger">No results found.</div>
    <?php endif; ?>
    <?php get_footer(); ?>