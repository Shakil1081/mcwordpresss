<?php
$slider = new WP_Query(array(
    'posts_per_page' => -1,
    'post_type' => 'slider',
    'orderby' => 'menu_order',
    'order' => 'asc'
        ));
if ($slider->have_posts()):
    ?>
    <div class="jumbotron">

        <div class="carousel slide topCaros" id="topCaros" data-interval="3000" data-ride="carousel"><!-- class of slide for animation -->
            <div class="carousel-inner">
                <?php
                $index = 0;
                while ($slider->have_posts()):$slider->the_post();
                    ?>
                    <div class="item <?php if ($index == 0): ?>active<?php endif; ?>"><!-- class of active since it's the first item -->
                        <?php
                        if ((function_exists('has_post_thumbnail')) && (has_post_thumbnail())):
                            $image_id = get_post_thumbnail_id();
                            $image_url = wp_get_attachment_image_src($image_id, 'full');
                            $image_url = $image_url[0];
                            $blogurl = get_bloginfo('url');
                            $image_url = str_replace($blogurl, '', $image_url);
                            ?>
                            <img alt="<?php the_title(); ?>" class="crsl" src="<?php bloginfo('template_url'); ?>/timthumb.php?src=<?php echo $image_url; ?>&amp;w=1600&amp;h=468&amp;zc=1&amp;q=80" />                            
                            <?php
                        endif;
                        ?>                        
                    </div>
                    <?php
                    $index++;
                endwhile;
                wp_reset_query();
                ?>
            </div><!-- /.carousel-inner -->
            <!--  Next and Previous controls below
                  href values must reference the id for this carousel -->
            <a class="carousel-control left" href="#topCaros" data-slide="prev">&lsaquo;</a>
            <a class="carousel-control right" href="#topCaros" data-slide="next">&rsaquo;</a>
        </div><!-- /.carousel -->
    </div>
<?php endif; ?>