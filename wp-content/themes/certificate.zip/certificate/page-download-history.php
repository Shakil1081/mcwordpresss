<?php
if (!is_user_logged_in()) {
    wp_redirect(home_url());
}
get_header();
?>
    <div class="clr"></div>
    <div class="bg vendor-bg">
    	<form method="get" action="<?php echo get_page_link(get_post_using_slug('search-exams')); ?>" onsubmit="if(this.s.value == '' || this.s.value == 'Enter Exam Code ...'){ alert('Kindly type something in Search field');return false;}">
    	
			<div id="top_search">
					<input type="text" name="word" placeholder="Enter Exam Code"/>
					<input type="submit" name="submit" value="" id="top_search_button"/>
				</div>
    	</form>
    	</div>
	</div>
    <div class="inner">
    	<br/>
        <ol class="breadcrumb">
            <li><a href="<?php echo home_url(); ?>">Home</a></li> 
            <li class="del">></li>           
            <li class="active">Download History</li>
        </ol>
        
        <div class="clr"></div>
    </div>
    <div class="inner mainParas zeroMarginTop zeroPaddingTop">
        <div class="account_menu_s col-md-3 col-sm-4 col-xs-12 mp">
            <h2 class="pull-left">Members Area</h2>
            <div class="clear"></div>
            <div class="tab-content popularCerts">
                <div class="tab-pane active" id="ci">
                    <?php include(TEMPLATEPATH . '/membersAreaLinks.php'); ?>
                </div>
            </div>
        </div>
        <div class="col-md-9 col-sm-8 col-xs-12 mp">
            <h2>Download History</h2>
            <?php
            global $wpdb;
            $downloadExamsHistoryTable = $wpdb->prefix . "download_exam_history";
            $downloads = $wpdb->get_results("select * from $downloadExamsHistoryTable where user_id = " . get_current_user_id() . " order by createdAt desc");
            if ($downloads):
                ?>
                <table  class="footable table" data-sort="false">
                    <thead>
                        <tr>
                            <th>
                                Order#
                            </th>
                            <th data-hide="phone">
                                Order Date
                            </th>
                            <th>
                                Exam Code
                            </th>
                            <th data-hide="phone">
                                Item Name
                            </th>
                            <th data-hide="phone">
                                Download Date
                            </th>
                            <th data-hide="phone">
                                Type
                            </th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        foreach ($downloads as $download) :
                            $order = new WC_Order($download->order_id);
                            $exam = get_post($download->exam_id);
                            ?>
                            <tr>
                                <td>
                                    <?php
                                    if ($download->order_id != 0)
                                        echo $order->get_order_number();
                                    else
                                        echo '-';
                                    ?>
                                </td>
                                <td>
                                    <?php
                                    if ($download->order_id != 0)
                                        echo date('M d, Y', strtotime($order->order_date));
                                    else
                                        echo '-';
                                    ?>
                                </td>
                                <td>
                                    <?php echo $exam->post_title; ?>
                                </td>
                                <td>
                                    <?php echo get_post_meta($exam->ID, 'exam_full_name', true); ?>
                                </td>
                                <td>
                                    <?php echo date('M d, Y h:i A', strtotime($download->createdAt)); ?>
                                </td>
                                <td>
                                    <?php
                                    if ($download->demo)
                                        echo 'Demo';
                                    else
                                        echo 'Full';
                                    ?>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            <?php else: ?>
                <div class="alert alert-danger">No downloads found.</div>
            <?php endif; ?>
            <div class="clr"></div>
        </div>
        <div class="clr"></div>
    </div>
    <script>
        $ = jQuery;
        $(document).ready(function() {
            $('.dHistory').addClass('active');
        });
    </script>
    <?php get_footer(); ?>