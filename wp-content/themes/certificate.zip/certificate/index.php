<?php get_header(); ?>

<div class="bg">
	<div class="woman">
		<div class="man">
		
			<div class="inner">
			<h2>Passing Your Certification Exam with Guarantee</h2>
			<form method="get" action="<?php echo get_page_link(get_post_using_slug('search-exams')); ?>" onsubmit="if(this.s.value == '' || this.s.value == 'Enter Exam Code ...'){ alert('Kindly type something in Search field');return false;}">
				<div id="top_search">
					<input type="text" name="word" placeholder="Enter Exam Code"/>
					<input type="submit" name="submit" value="" id="top_search_button"/>
				</div>
			</div>
			</form>
		</div>
	</div>
</div>

    <?php
    //get product cat
    $args = array(
        'type' => 'product',
        'child_of' => 0,
        'parent' => 0,
        'orderby' => 'name',
        'order' => 'ASC',
        'hide_empty' => 0,
        'hierarchical' => 1,
        'exclude' => '',
        'include' => '',
        'number' => '',
        'taxonomy' => 'product_cat',
        'pad_counts' => false,
    );
    $prodCats = get_categories($args);
    ?>
   <div class="brands_section">
		<div class="inner">
			<div class="brands">
    <?php wp_nav_menu(array('theme_location' => 'sub-header-menu', 'container' => '', 'items_wrap' => '%3$s', 'walker' => new Top_Category_Walker)); ?>
    		</div>
    	</div>
    </div>
    <div class="testim">
		<div class="inner">
			<h4><?php echo get_option('welcome_title'); ?></h4>
			<?php echo get_option('welcome_body '); ?>
		</div>
	</div>
    
    <div class="bg-certif">
		<div class="inner">
			<div class="popular-certification">
				<h4>Popular Exams</h4>
				<div class="certification-buttons">
					<div class="inner" id="popular_tabs">
						<?php
					    //get popular cat
					    $first = true;
					    $popularCats = $wpdb->get_results("select t.* from $wpdb->terms t join $wpdb->term_taxonomy tt where tt.term_id = t.term_id and tt.taxonomy = 'product_cat' and tt.parent = 0 and t.is_popular = true order by t.name asc limit 4");
					    foreach ($popularCats as $popularCat):
					        $catObject = get_term_by('id', $popularCat->term_id, 'product_cat');
					        ?>
					        <div class="<?= ($first) ? 'active' : '' ?>"><a href="<?php echo get_category_link($catObject);?>"><?php echo $catObject->name ?></a></div>
					        <? $first = false; ?>
					    <?php endforeach; ?>
					</div>
					<div class="clr"></div>
				</div>
				<div class="buttons" id="popular_tabs_tabs">
					<?php
				    //get popular cat
				    $first = true;
				    $popularCats = $wpdb->get_results("select t.* from $wpdb->terms t join $wpdb->term_taxonomy tt where tt.term_id = t.term_id and tt.taxonomy = 'product_cat' and tt.parent = 0 and t.is_popular = true order by t.name asc limit 4");
				    foreach ($popularCats as $popularCat):
				        $catObject = get_term_by('id', $popularCat->term_id, 'product_cat');
				            $exams = new WP_Query(array(
				                'posts_per_page' => 24,
				                'post_type' => 'product',
				                'meta_key' => 'is_popular',
				                'meta_value' => '1',
				                'tax_query' => array(
				                    array(
				                        'taxonomy' => 'product_cat',
				                        'field' => 'slug',
				                        'terms' => $popularCat->slug
				                    )
				                )
				            ));
				            $examsCount = count($exams->get_posts());
				            $index = 0;
				            ?>
				            
							<div class="tab <?= ($first) ? '' : 'hidden_tab' ?>">
								<ul>
								<?
								$first = false;
					            while ($exams->have_posts()):$exams->the_post();
					                $index++;
					                ?>
					                <li><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></li>
					                <?php
					            endwhile;
					            ?>
								</ul>
								<div class="clr"></div>
							</div>
			            
						    <? wp_reset_query(); ?>
				            
				    <?php endforeach; ?>
				</div>
			</div>
			<div class="popular-certification">
				<h4>Random Certifications</h4>
				<div class="buttons random-cert" id="popular_tabs_tabs">
					<div class="tab">
						<ul>
							<?php
				            //get top certificat cat
				            $topCertificatCats = $wpdb->get_results("select t.* from $wpdb->terms t join $wpdb->term_taxonomy tt where tt.term_id = t.term_id and tt.taxonomy = 'product_cat' and tt.parent <> 0 and t.is_top_certificat = true order by t.name asc limit 24");
				            $topCertificatCatsCount = count($topCertificatCats);
				            $index = 0;
				            foreach ($topCertificatCats as $topCertificatCat):
				                $topCertificatCatObject = get_term_by('id', $topCertificatCat->term_id, 'product_cat');
			                    ?>
			                    <li>
			                    	<a href="<?php echo get_category_link($topCertificatCatObject); ?>">
			                    		<?php echo $topCertificatCat->name; ?>
			                    	</a>
			                    </li>
			                    <?php
				            endforeach;
				            ?>
							<div class="clr"></div>
						</ul>
					</div>
				</div>
			</div>
		</div>
		<div class="clr"></div>
	</div>
	<div class="clr"></div>
<meta name="google-site-verification" content="c2P0plne3wokioCuhI7M4hfloMZn8n4vTiBZww4NXGM" />
    <?php get_footer(); ?>