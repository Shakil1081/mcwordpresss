<?php  session_start();
/**
 * The Template for displaying product archives, including the main shop page which is a post type archive.
 *
 * Override this template by copying it to yourtheme/woocommerce/archive-product.php
 *
 * @author 		WooThemes
 * @package 	WooCommerce/Templates
 * @version     2.0.0
 */
 
if (!defined('ABSPATH'))
    exit; // Exit if accessed directly
//

get_header('shop');
if (get_query_var('term')):
//check if parent
    $catObject = get_term_by('slug', get_query_var('term'), 'product_cat');
//    $args = array(
//        'type' => 'product',
//        'child_of' => 0,
//        'parent' => $catObject->term_id,
//        'orderby' => 'name',
//        'order' => 'ASC',
//        'hide_empty' => 0,
//        'hierarchical' => 1,
//        'exclude' => '',
//        'include' => '',
//        'number' => '',
//        'taxonomy' => 'product_cat',
//        'pad_counts' => false
//    );
//    $subCats = get_categories($args);
    global $wpdb; 
?>

	<?php 
    $subCats = $wpdb->get_results("select t.name,t.slug,t.term_id,tt.count from $wpdb->terms t join $wpdb->term_taxonomy tt on t.term_id = tt.term_id where tt.taxonomy = 'product_cat' and tt.parent = " . $catObject->term_id . " order by t.name asc");
//    print_r($subCats);exit;
    if (count($subCats) > 0):
	
	
	
	global $wp_query;
$category_name = $wp_query->query_vars['product_cat'];

if( $category_name ) {
$category_object = get_term_by('name', $category_name, 'product_cat');
$_SESSION['cat'] = $category_id = $category_object->term_id;
}
	
        ?>
	 
		
        <div class="clr"></div>
        <div class="bg vendor-bg">
        	<form method="get" action="<?php echo get_page_link(get_post_using_slug('search-exams')); ?>" onsubmit="if(this.s.value == '' || this.s.value == 'Enter Exam Code ...'){ alert('Kindly type something in Search field');return false;}">
        	
				<div id="top_search">
					<input type="text" name="word" placeholder="Enter Exam Code"/>
					<input type="submit" name="submit" value="" id="top_search_button"/>
				</div>
        	</form>
        	</div>
		</div>
		<div class="clr"></div>
		<div class="content-exams">
			<div class="inner">
				<?php
                $args = array(
                    'wrap_before' => '<ol class="breadcrumb">',
                    'wrap_after' => '</ol>',
                    'before' => '<li>',
                    'after' => '</li>',
                    'delimiter' => '<li class="del">></li>',
                );
                woocommerce_breadcrumb($args);
                ?>
                <div class="clr"></div>
			</div>
		</div>
		<div class="exams">
			<div class="inner">
				<ul>
					<?php
	                foreach ($subCats as $subCat):
	                    $subCatObject = get_term_by('id', $subCat->term_id, 'product_cat');
	                    ?>
	                    <li>
							<div class="main">
								<a href="<?php echo get_category_link($subCatObject); ?>">
									<h5><?php echo $subCat->count; ?></h5>
									<p>Exams<br><span><?php echo $subCat->name; ?></span></p>
								</a>
							</div>
						</li>
						
	                    
	                <?php endforeach; ?>
				</ul>
				<div class="clr"></div>
			</div>
		</div>
		
		<div class="clr"></div>
		<div class="updated-exams releases">
			<div class="buttons">
				<div class="inner">
				
		
				
					<h5>New <?php single_cat_title(); ?> Releases</h5>
					
					 
					
					<div class="tab">
						
						<?php
add_shortcode( 'bestselling_product_categories', 'sp_bestselling_products' );
function sp_bestselling_products($atts){
	global $woocommerce_loop;
	extract(shortcode_atts(array(
		'cats' => '',	
		'tax' => 'product_cat',	
		'per_cat' => '3',	
		'columns' => '3',	
	), $atts));
	if(empty($cats)){
		$terms = get_terms( 'product_cat', array('hide_empty' => true, 'fields' => 'ids'));
		$cats = implode(',', $terms);
	}
	$cats = explode(',', $cats);
	if(empty($cats)){
		return '';
	}
	$cats = array_splice($cats, 0,5);
	ob_start();
	foreach($cats as $cat){
		// get the product category
		$term = get_term( $cat, $tax);
		// setup query
		$args = array(
			'post_type' 			=> 'product',
			'post_status' 			=> 'publish',
			'ignore_sticky_posts'   => 1,
			'posts_per_page'		=> $per_cat,			
			'meta_key' 		 		=> '',
			'orderby' 		 		=> 'desc',
			'tax_query' => array(				
				array(
					'taxonomy' => $tax,
					'field' => 'id',
					'terms' => $cat,
				)
			),
			'meta_query' 			=> 
			array(
				array(
					'key' 		=> '_visibility',
					'value' 	=> array( 'catalog', 'visible' ),
					'compare' 	=> 'IN'
				)
			)
		);
		// set woocommerce columns
		$woocommerce_loop['columns'] = $columns;
		// query database
		$products = new WP_Query( $args );
		$woocommerce_loop['columns'] = $columns;
if ( $products->have_posts() ) : ?>
<?php woocommerce_product_loop_start(); ?>
<ul>
<?php while ( $products->have_posts() ) : $products->the_post(); ?>
<li><a href="<?php the_permalink(); ?>"><?php the_title(); ?></br><span><?php echo get_the_date('M d, Y'); ?></span></a></li>
<?php
endwhile;
?>
<div class="clr"></div>
</ul>
<?php //woocommerce_get_template_part( 'content', 'product' ); ?>
<?php //endwhile; // end of the loop. ?>
<?php woocommerce_product_loop_end(); ?>
<?php endif;
wp_reset_postdata();
}
return '<div class="woocommerce columns-' . $columns . '">' . ob_get_clean() . '</div>';
}
?>
<?php echo do_shortcode('[bestselling_product_categories cats="'.$category_id.'" per_cat="30"]'); ?>
					</div>
				</div>
			</div>
			<div class="buttons">
				<div class="inner">
					<h5>Updated <?php single_cat_title(); ?> Exams</h5>
					<div class="tab">
 
 <?php
add_shortcode( 'latest_product_categories', 'sp_latest_products' );
function sp_latest_products($atts){
global $woocommerce_loop;
extract(shortcode_atts(array(
'cats' => '',	
'tax' => 'product_cat',	
'per_cat' => '3',	
'columns' => '3',	
), $atts));
if(empty($cats)){
$terms = get_terms( 'product_cat', array('hide_empty' => true, 'fields' => 'ids'));
$cats = implode(',', $terms);
}
$cats = explode(',', $cats);
if(empty($cats)){
return '';
}
$cats = array_splice($cats, 0,5);
ob_start();
foreach($cats as $cat){
// get the product category
$term = get_term( $cat, $tax);
// setup query
$args = array(
'post_type' 			=> 'product',
'post_status' 			=> 'publish',
'ignore_sticky_posts'   => 1,
'posts_per_page'		=> $per_cat,			
'meta_key' 		 		=> 'total_sales',
'orderby' 		 		=> 'meta_value_num',
'tax_query' => array(				
array(
'taxonomy' => $tax,
'field' => 'id',
'terms' => $cat,
)
),
'meta_query' 			=> array(
array(
'key' 		=> '_visibility',
'value' 	=> array( 'catalog', 'visible' ),
'compare' 	=> 'IN'
)
)
);
// set woocommerce columns
$woocommerce_loop['columns'] = $columns;
// query database
$products = new WP_Query( $args );
$woocommerce_loop['columns'] = $columns;
if ( $products->have_posts() ) : ?>
<?php woocommerce_product_loop_start(); ?>
<ul>
<?php while ( $products->have_posts() ) : $products->the_post(); ?>
<li><a href="<?php the_permalink(); ?>"><?php the_title(); ?></br><span><?php echo get_the_date('M d, Y'); ?></span></a></li>
<?php
endwhile;
?>
<div class="clr"></div>
</ul>
<?php //woocommerce_get_template_part( 'content', 'product' ); ?>
<?php //endwhile; // end of the loop. ?>
<?php woocommerce_product_loop_end(); ?>
<?php endif;
wp_reset_postdata();
}
return '<div class="woocommerce columns-' . $columns . '">' . ob_get_clean() . '</div>';
}
?>
<?php echo do_shortcode('[latest_product_categories cats="'.$category_id.'" per_cat="30"]'); ?>

 
 
					</div>
					
					 
					
					
					
				</div>
			</div>
		</div>
		<div class="testim vendor-testim">
			<div class="inner">
				<?php
                    if ($catObject->description) {
                        echo $catObject->description;
                    } else {
                        $defaultDesc = get_option('vendor_description');
                        $defaultDesc = str_replace('[recent_exams]', do_shortcode('[recent_exams]'), $defaultDesc);
                        echo str_replace("{%V-name%}", $catObject->name, $defaultDesc);
                    }
                    ?>
                <div class="clr"></div>
			</div>
		</div>
		<div class="clr"></div>
		

		
                  <?php
        else:
		
		
		global $post;
		$terms = get_the_terms( $post->ID, 'product_cat' );

		foreach ($terms as $term) {
			$product_cat_id = $term->term_id;
			$_SESSION['cat'] = $product_cat_id;
			
			$product_cat_name = $term->name; 
			$_SESSION['catname'] = $product_cat_name;
			break;
		} 
		global $wpdb;
		$q = $wpdb->get_results("select * from ".$wpdb->prefix."_term_taxonomy where term_id='".$_SESSION['cat']."'");
		if($q[0]->parent == 0) {
			$b['parent'] = $_SESSION['cat'];
			$d['name'] = $_SESSION['catname'];
		} else {
			$b['parent'] = $q[0]->parent;
			$q = $wpdb->get_results("select * from  ".$wpdb->prefix."_terms where term_id='". $b['parent']."'");

			$d['name'] = $q[0]->name;
		}		
		 
		
            ?>
			
			
			
			
            <div class="clr"></div>
	        <div class="bg vendor-bg">
	        	<form method="get" action="<?php echo get_page_link(get_post_using_slug('search-exams')); ?>" onsubmit="if(this.s.value == '' || this.s.value == 'Enter Exam Code ...'){ alert('Kindly type something in Search field');return false;}">
	        	
					<div id="top_search">
					<input type="text" name="word" placeholder="Enter Exam Code"/>
					<input type="submit" name="submit" value="" id="top_search_button"/>
				</div>
	        	</form>
	        	</div>
			</div>
			<div class="content-exams">
				<div class="inner">
					<?php
	                $args = array(
	                    'wrap_before' => '<ol class="breadcrumb">',
	                    'wrap_after' => '</ol>',
	                    'before' => '<li>',
	                    'after' => '</li>',
	                    'delimiter' => '<li class="del">></li>',
	                );
	                woocommerce_breadcrumb($args);
	                ?>
				</div>
				<div class="clr"></div>
			</div>
			<div class="exams">
				<div class="inner">
					<ul>
						<?php while (have_posts()) : the_post(); ?>
							<li>
								<div class="main">
									<a href="<?php the_permalink(); ?>">
										<h5><?php the_title(); ?></h5>
										<p><?php echo get_the_date('M d, Y'); ?></br><span><?php echo get_post_meta(get_the_ID(), 'exam_full_name', TRUE); ?></span></p>
									</a>
								</div>
							</li>
							
	                       
	                        <?php
	                    endwhile;
	                    wp_reset_query();
	                    ?>
	                    <?php
	                    /**
	                     * woocommerce_after_shop_loop hook
	                     *
	                     * @hooked woocommerce_pagination - 10
	                     */
	                    do_action('woocommerce_after_shop_loop');
	                    ?>
						
						
					</ul>
					<div class="clr"></div>
				</div>
			</div>
			<div class="updated-exams releases">
				<div class="buttons">
					<div class="inner">
					
									
						<h5>New <?php echo $d['name'];?> Releases</h5>
						
						<div class="tab">
<?php
add_shortcode( 'bestselling_product_categories', 'sp_bestselling_products' );
function sp_bestselling_products($atts){
	global $woocommerce_loop;
	extract(shortcode_atts(array(
	'cats' => '',	
	'tax' => 'product_cat',	
	'per_cat' => '3',	
	'columns' => '3',	
	), $atts));
	
	if(empty($cats)){
		$terms = get_terms( 'product_cat', array('hide_empty' => true, 'fields' => 'ids'));
		$cats = implode(',', $terms);
	}
	
	$cats = explode(',', $cats);
	if(empty($cats)){
		return '';
	}
	ob_start();
	foreach($cats as $cat){
	// get the product category
	$term = get_term( $cat, $tax);
	// setup query
	$args = array(
		'post_type' 			=> 'product',
		'post_status' 			=> 'publish',
		'ignore_sticky_posts'   => 1,
		'posts_per_page'		=> $per_cat,			
		'meta_key' 		 		=> '',
		'orderby' 		 		=> 'desc',
		'tax_query' => array(				
		array(
		'taxonomy' => $tax,
		'field' => 'id',
		'terms' => $cat,
		)
		),
		'meta_query' 			=> array(
		array(
		'key' 		=> '_visibility',
		'value' 	=> array( 'catalog', 'visible' ),
		'compare' 	=> 'IN'
		)
		)
	);


	// set woocommerce columns
	$woocommerce_loop['columns'] = $columns;
	// query database
	$products = new WP_Query( $args );
	$woocommerce_loop['columns'] = $columns;
if ( $products->have_posts() ) : ?>
<?php woocommerce_product_loop_start(); ?>
<ul>
<?php while ( $products->have_posts() ) : $products->the_post(); ?>
<li><a href="<?php the_permalink(); ?>"><?php the_title(); ?></br><span><?php echo get_the_date('M d, Y'); ?></span></a></li>
<?php
endwhile;
?>
<div class="clr"></div>
</ul>
<?php //woocommerce_get_template_part( 'content', 'product' ); ?>
<?php //endwhile; // end of the loop. ?>
<?php woocommerce_product_loop_end(); ?>
<?php endif;
wp_reset_postdata();
}
return '<div class="woocommerce columns-' . $columns . '">' . ob_get_clean() . '</div>';
}
?>

<?php if(is_product_category( 'Cisco Specialist' )) { ?>
<?php echo do_shortcode('[bestselling_product_categories cats="36" per_cat="30"]'); ?>			 
<?php } else {  ?>
<?php echo do_shortcode('[bestselling_product_categories cats="'.$b['parent'].'" per_cat="30"]'); ?>
<?php } ?>
</div>
						
						
						
					</div>
				</div>
				<div class="buttons">
					<div class="inner">
						<h5>Updated <?php //echo $_SESSION['catname']; ?> <?php echo $d['name'];?> Exams</h5>
						<?php /*?><div class="tab">
							<?php
	                        //get latest cat exams
	                        $latestExams = new WP_Query(array(
	                            'posts_per_page' => 10,
	                            'post_type' => 'product',
	                            'orderby' => 'modified',
	                            'order' => 'desc',
	                            'tax_query' => array(
	                                array(
	                                    'taxonomy' => 'product_cat',
	                                    'field' => 'slug',
	                                    'terms' => get_query_var('term')
	                                )
	                            )
	                        ));
	                        ?>
	                        <ul>
	                            <?php while ($latestExams->have_posts()):$latestExams->the_post(); ?>
	                            	<li><a href="<?php the_permalink(); ?>"><?php the_title(); ?></br><span><?php echo get_the_date('M d, Y'); ?></span></a></li>
	                                <?php
	                            endwhile;
	                            wp_reset_query();
	                            ?>
	                            <div class="clr"></div>
							</ul>
						</div><?php */?>
						
						<div class="tab">
<?php
add_shortcode( 'latest_product_categories', 'sp_latest_products' );
function sp_latest_products($atts){
global $woocommerce_loop;
extract(shortcode_atts(array(
'cats' => '',	
'tax' => 'product_cat',	
'per_cat' => '3',	
'columns' => '3',	
), $atts));
if(empty($cats)){
$terms = get_terms( 'product_cat', array('hide_empty' => true, 'fields' => 'ids'));
$cats = implode(',', $terms);
}
$cats = explode(',', $cats);
if(empty($cats)){
return '';
}
ob_start();
foreach($cats as $cat){
// get the product category
$term = get_term( $cat, $tax);
// setup query
$args = array(
'post_type' 			=> 'product',
'post_status' 			=> 'publish',
'ignore_sticky_posts'   => 1,
'posts_per_page'		=> $per_cat,			
'meta_key' 		 		=> 'total_sales',
'orderby' 		 		=> 'meta_value_num',
'tax_query' => array(				
array(
'taxonomy' => $tax,
'field' => 'id',
'terms' => $cat,
)
),
'meta_query' 			=> array(
array(
'key' 		=> '_visibility',
'value' 	=> array( 'catalog', 'visible' ),
'compare' 	=> 'IN'
)
)
);
// set woocommerce columns
$woocommerce_loop['columns'] = $columns;
// query database
$products = new WP_Query( $args );
$woocommerce_loop['columns'] = $columns;
if ( $products->have_posts() ) : ?>
<?php woocommerce_product_loop_start(); ?>
<ul>
<?php while ( $products->have_posts() ) : $products->the_post(); ?>
<li><a href="<?php the_permalink(); ?>"><?php the_title(); ?></br><span><?php echo get_the_date('M d, Y'); ?></span></a></li>
<?php
endwhile;
?>
<div class="clr"></div>
</ul>
<?php //woocommerce_get_template_part( 'content', 'product' ); ?>
<?php //endwhile; // end of the loop. ?>
<?php woocommerce_product_loop_end(); ?>
<?php endif;
wp_reset_postdata();
}
return '<div class="woocommerce columns-' . $columns . '">' . ob_get_clean() . '</div>';
}
?>
<?php if(is_product_category( 'Cisco Specialist' )) { ?>
<?php echo do_shortcode('[latest_product_categories cats="36" per_cat="30"]'); ?>
<?php }else { ?>
<?php echo do_shortcode('[latest_product_categories cats="'.$b['parent'].'" per_cat="30"]'); ?>
<?php } ?>
</div>
						
						
						
						
					</div>
				</div>
			</div>
			<div class="testim vendor-testim">
			<div class="inner">
				 <?php
				if ($catObject->description) {
                    echo $catObject->description;
                } else {
                    $catParentObject = get_term_by('id', $catObject->parent, 'product_cat');
                    $defaultDesc = get_option('certification_description');
                    $defaultDesc = str_replace("{%V-name%}", $catParentObject->name, $defaultDesc);
                    $defaultDesc = str_replace("{%Cert-name%}", $catObject->name, $defaultDesc);
                    $defaultDesc = str_replace('[recent_exams]',"", $defaultDesc);
                    echo $defaultDesc;
                }
                ?>
              <div class="clr"></div>
			</div>
		</div>
						
            <?php
            endif;
        else:
        $args = array(
            'type' => 'product',
            'child_of' => 0,
            'parent' => 0,
            'orderby' => 'name',
            'order' => 'ASC',
            'hide_empty' => 0,
            'hierarchical' => 1,
            'exclude' => '',
            'include' => '',
            'number' => '',
            'taxonomy' => 'product_cat',
            'pad_counts' => false
        );
        $topCats = get_categories($args);
        ?>
            <div class="clr"></div>
	        <div class="bg vendor-bg">
	        	<form method="get" action="<?php echo get_page_link(get_post_using_slug('search-exams')); ?>" onsubmit="if(this.s.value == '' || this.s.value == 'Enter Exam Code ...'){ alert('Kindly type something in Search field');return false;}">
	        	
					<div id="top_search">
					<input type="text" name="word" placeholder="Enter Exam Code"/>
					<input type="submit" name="submit" value="" id="top_search_button"/>
				</div>
	        	</form>
	        	</div>
			</div>
			<div class="clr"></div>
			<div class="content-exams">
				<div class="inner">
					<?php
	                $args = array(
	                    'wrap_before' => '<ol class="breadcrumb">',
	                    'wrap_after' => '</ol>',
	                    'before' => '<li>',
	                    'after' => '</li>',
	                    'delimiter' => '<li class="del">></li>',
	                );
	                woocommerce_breadcrumb($args);
	                ?>
				</div>
                <div class="updated-exams">
                	<div class="buttons">
						<div class="inner" style="padding-bottom:34px;">
							<ul>
	                    <?php
	                    foreach ($topCats as $subCat):
	                        $thumbnail_id = get_woocommerce_term_meta($subCat->term_id, 'thumbnail_id', true);
	                        $image = null;
	                        if ($thumbnail_id)
	                            $image = wp_get_attachment_url($thumbnail_id);
	                        ?>
	                        <li>
	                        	<a href="<?php echo get_category_link($subCat); ?>"><?php echo $subCat->name; ?></br><span>See Details</span></a></li>

	                      
	                    <?php endforeach; ?>
	                    	</ul>
                    	<div class="clr"></div>
					</div>
				</div>
			</div>
            <?php
            endif;
            get_footer('shop');
            ?>