<?php
/**
 * Login Form
 *
 * @author 		WooThemes
 * @package 	WooCommerce/Templates
 * @version     2.2.6
 */
if (!defined('ABSPATH'))
    exit; // Exit if accessed directly


require_once dirname(__FILE__) . '/../../recaptcha/recaptchalib.php';
$privatekey = get_option('recaptcha_private_key');
$publickey = get_option('recaptcha_public_key');
?>

<?php wc_print_notices(); ?>

<?php do_action('woocommerce_before_customer_login_form'); ?>

<div class="col-sm-6 col-xs-12">
    <form method="post" class="form-horizontal">
        <div class="form-group reg-form">
            <div class="col-sm-offset-4 col-sm-8">
                <h2><?php _e('Sign In Here', 'woocommerce'); ?></h2>
            </div>
        </div>
        <?php do_action('woocommerce_login_form_start'); ?>

        <div class="form-group reg-form">
            <label for="username" class="col-sm-4 control-label"><?php _e('Email address', 'woocommerce'); ?></label>
            <div class="col-sm-8">
                <input type="text" class="form-control input-text" name="username" id="username" placeholder="Email address"/>
            </div>
        </div>
        <div class="form-group reg-form">
            <label for="password" class="col-sm-4 control-label"><?php _e('Password', 'woocommerce'); ?></label>
            <div class="col-sm-8">
                <input type="password" name="password" class="form-control input-text" id="password" placeholder="Password">
            </div>
        </div>

        <?php do_action('woocommerce_login_form'); ?>

        <p class="form-row">
            <?php wp_nonce_field('woocommerce-login'); ?>
        </p>

        <div class="form-group reg-form">
            <div class="col-sm-offset-4 col-sm-8">
                <div class="checkbox">
                    <label>
                        <input name="rememberme" type="checkbox" id="rememberme" value="forever" /> <?php _e('Remember me', 'woocommerce'); ?>
                    </label>
                    <br/>
                    <a class="lost_password" href="<?php echo esc_url(wc_lostpassword_url()); ?>"><?php _e('Lost your password?', 'woocommerce'); ?></a>
                </div>
            </div>
        </div>
        <div class="form-group reg-form">
            <div class="col-sm-offset-4 col-sm-8">
                <input type="submit" class="btn btn-default lnk-1" name="login" value="<?php _e('Login', 'woocommerce'); ?>" />
            </div>
        </div>        


        <?php do_action('woocommerce_login_form_end'); ?>

    </form>
</div>
<?php if (get_option('woocommerce_enable_myaccount_registration') === 'yes') : ?>
    <div class="col-sm-6 col-xs-12 vert-sepa">

        <script type="text/javascript">
            var RecaptchaOptions = {
                theme: 'red',
                lang: 'en'
            };
        </script>
        <?php
        $error = FALSE;
        if (isset($_POST['user_email']) && $_POST['user_email']) {
            //chk for email
            if (preg_match("/^[a-zA-Z]\w+(\.\w+)*\@\w+(\.[0-9a-zA-Z]+)*\.[a-zA-Z]{2,4}$/", $_POST["user_email"]) === 0) {
                echo '<div class="alert alert-danger">Please enter a valid email.</div>';
                $error = TRUE;
            } elseif (email_exists($_POST['user_email'])) {
                echo '<div class="alert alert-danger">Email Exist.</div>';
                $error = TRUE;
            }

            //chk for password
            if (trim($_POST['password']) == '') {
                echo '<div class="alert alert-danger">Password must be 6 digits length.</div>';
                $error = TRUE;
            } else {
                if (strlen(trim($_POST['password'])) < 6) {
                    echo '<div class="alert alert-danger">Password must be 6 digits length.</div>';
                    $error = TRUE;
                } elseif (trim($_POST['password']) != trim($_POST['repassword'])) {
                    echo '<div class="alert alert-danger">Password do not match.</div>';
                    $error = TRUE;
                }
            }

           /* //chk for captcha
            $resp = recaptcha_check_answer($privatekey, $_SERVER["REMOTE_ADDR"], $_POST["recaptcha_challenge_field"], $_POST["recaptcha_response_field"]);
            if (!$resp->is_valid) {
                echo "<div class='alert alert-danger'>CAPTCHA wasn't entered correctly.</div>";
                $error = TRUE;
            } */

            if (!$error) {
                $userdata = array(
                    'user_pass' => $_POST['password'],
                    'user_login' => $_POST['user_email'],
                    'user_nicename' => $_POST['user_first_name'] . ' ' . $_POST['user_last_name'],
                    'user_email' => $_POST['user_email'],
                    'display_name' => $_POST['user_first_name'] . ' ' . $_POST['user_last_name'],
                    'first_name' => $_POST['user_first_name'],
                    'last_name' => $_POST['user_last_name'],
                    'user_registered' => current_time('mysql')
                );

                $user_id = wp_insert_user($userdata);
                if ($user_id) {
                    global $wpdb;
                    if (isset($_POST['newsletters']) && $_POST['newsletters'] == 1) {
                        $newsletterTableName = $wpdb->prefix . 'eemail_newsletter_sub';
                        //check if this email exist
                        $userEmail = $_POST['user_email'];
                        $flag = $wpdb->get_row("select * from $newsletterTableName where eemail_email_sub = '$userEmail'");
                        if (!$flag) {
                            //add newsletter
                            $wpdb->insert($newsletterTableName, array(
                                'eemail_name_sub' => $_POST['user_first_name'] . ' ' . $_POST['user_last_name'],
                                'eemail_email_sub' => $_POST['user_email'],
                                'eemail_status_sub' => 'CON',
                                'eemail_date_sub' => current_time('mysql')
                            ));
                        }
                    }

                    //register success
                    //send welcome email to user
                    $headers = 'From: ExamsBoost<"' . get_option('admin_email') . '">' . "\r\n";
                    $userEmail = $_POST['user_email'];
                    $message = "<h1>Welcome to ExamsBoost</h1><br/>
                                <p>Thanks for creating an account on ExamsBoost. Your username is $userEmail.</p><br/><br/>
                                <p>You can access your account area to view your orders and change your password here: </p><br/> 
                                <p>
                               " . get_page_link(get_post_using_slug('my-account')) . "</p>";

                    wp_mail($userEmail, 'Your account on ExamsBoost', $message, $headers);

                    $_POST = array();
                    echo "<div class='alert alert-success'>Register success you can login now.</div>";
                }
            }
        }
        ?>
        <form class="form-horizontal" role="form" method="post">
            <div class="form-group reg-form">
                <div class="col-sm-offset-4 col-sm-8">
                    <h2>Sign Up Here</h2>
                </div>
            </div>
            <div class="form-group reg-form">
                <label class="col-sm-4 control-label">First Name</label>
                <div class="col-sm-8">
                    <input type="text" class="form-control" placeholder="First Name" name="user_first_name" value="<?php if (!empty($_POST['user_first_name'])) esc_attr_e($_POST['user_first_name']); ?>">
                </div>
            </div>
            <div class="form-group reg-form">
                <label class="col-sm-4 control-label">Last Name</label>
                <div class="col-sm-8">
                    <input type="text" class="form-control" placeholder="Last Name" name="user_last_name" value="<?php if (!empty($_POST['user_last_name'])) esc_attr_e($_POST['user_last_name']); ?>">
                </div>
            </div>
            <div class="form-group reg-form">
                <label class="col-sm-4 control-label">Email</label>
                <div class="col-sm-8">
                    <input type="email" class="form-control" placeholder="Email" required="" name="user_email" value="<?php if (!empty($_POST['user_email'])) esc_attr_e($_POST['user_email']); ?>">
                </div>
            </div>
            <div class="form-group reg-form">
                <label class="col-sm-4 control-label">Password</label>
                <div class="col-sm-8">
                    <input type="password" class="form-control" placeholder="Password" required="" name="password">
                </div>
            </div>
            <div class="form-group reg-form">
                <label class="col-sm-4 control-label">Confirm Password</label>
                <div class="col-sm-8">
                    <input type="password" class="form-control" placeholder="Confirm Password" required="" name="repassword">
                </div>
            </div>
            <div class="form-group reg-form">
                
			<div class="g-recaptcha" data-sitekey="6Lc7k1QUAAAAAIf-cq6APFSSfh72QReMRgVPExk5"></div>

            <div class="form-group reg-form">
                <label class="col-sm-4 control-label">Subscribe to Newsletters</label>
                <div class="col-sm-8">
                    <input type="checkbox" value="1" name="newsletters">
                </div>
            </div>
             <div class="form-group reg-form">
                <div class="col-sm-offset-4 col-sm-8">
                    <button class="btn btn-default lnk-2" type="submit">Sign Up</button>
                </div>
            </div> 
        </form>

        <!--
        <form method="post" class="register form-horizontal">
            <div class="form-group reg-form">
                <div class="col-sm-offset-4 col-sm-8">
                    <h2><?php _e('Register', 'woocommerce'); ?></h2>
                </div>
            </div>
        <?php do_action('woocommerce_register_form_start'); ?>

        <?php if (get_option('woocommerce_registration_generate_username') === 'no') : ?>


                                                                                                                                                                                                                <div class="form-group reg-form">
                                                                                                                                                                                                                <label for="username" class="col-sm-4 control-label"><?php _e('Username', 'woocommerce'); ?></label>
                                                                                                                                                                                                                <div class="col-sm-8">
                                                                                                                                                                                                                <input type="text" name="username" id="username" class="form-control" value="<?php if (!empty($_POST['username'])) esc_attr_e($_POST['username']); ?>">
                                                                                                                                                                                                                </div>
                                                                                                                                                                                                                </div>

        <?php endif; ?>

            <div class="form-group reg-form">
                <label for="email" class="col-sm-4 control-label"><?php _e('Email', 'woocommerce'); ?></label>
                <div class="col-sm-8">
                    <input type="email" name="email" id="email" class="form-control" value="<?php if (!empty($_POST['email'])) esc_attr_e($_POST['email']); ?>">
                </div>
            </div>

            <div class="form-group reg-form">
                <label for="password" class="col-sm-4 control-label"><?php _e('Password', 'woocommerce'); ?></label>
                <div class="col-sm-8">
                    <input type="password" name="password" id="password" class="form-control" value="<?php if (!empty($_POST['password'])) esc_attr_e($_POST['password']); ?>">
                </div>
            </div>





            <div style="left:-999em; position:absolute;"><label for="trap"><?php _e('Anti-spam', 'woocommerce'); ?></label><input type="text" name="email_2" id="trap" tabindex="-1" /></div>

        <?php do_action('woocommerce_register_form'); ?>
        <?php do_action('register_form'); ?>

            <p class="form-row">
        <?php wp_nonce_field('woocommerce-register', 'register'); ?>
            </p>

            <div class="form-group reg-form">
                <div class="col-sm-offset-4 col-sm-8">
                    <input type="submit" class="btn btn-default lnk-2" name="register" value="<?php _e('Register', 'woocommerce'); ?>" />
                </div>
            </div>
        <?php do_action('woocommerce_register_form_end'); ?>

        </form>
        -->

    </div>

<?php endif; ?>

<?php do_action('woocommerce_after_customer_login_form'); ?>