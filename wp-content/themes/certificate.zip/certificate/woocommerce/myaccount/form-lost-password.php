<?php
/**
 * Lost password form
 *
 * @author 		WooThemes
 * @package 	WooCommerce/Templates
 * @version     2.3.0
 */
if (!defined('ABSPATH'))
    exit; // Exit if accessed directly

global $woocommerce, $post;
?>

<?php wc_print_notices(); ?>

<div class="col-sm-12 col-xs-12">
    <form method="post" class="lost_reset_password form-horizontal">

        <?php if ('lost_password' == $args['form']) : ?>

            <p><?php echo apply_filters('woocommerce_lost_password_message', __('Lost your password? Please enter your username or email address. You will receive a link to create a new password via email.', 'woocommerce')); ?></p>

            <div class="form-group">
                <label for="user_login" class="col-sm-4 control-label"><?php _e('Username or email', 'woocommerce'); ?></label>
                <div class="col-sm-8">
                    <input type="text" class="form-control" name="user_login" id="user_login">
                </div>
            </div>
        <?php else : ?>

            <p><?php echo apply_filters('woocommerce_reset_password_message', __('Enter a new password below.', 'woocommerce')); ?></p>

            <div class="form-group">
                <label for="password_1" class="col-sm-4 control-label"><?php _e('New password', 'woocommerce'); ?></label>
                <div class="col-sm-8">
                    <input type="password" class="form-control" name="password_1" id="password_1">
                </div>
            </div>

            <div class="form-group">
                <label for="password_2" class="col-sm-4 control-label"><?php _e('Re-enter new password', 'woocommerce'); ?></label>
                <div class="col-sm-8">
                    <input type="password" class="form-control" name="password_2" id="password_2">
                </div>
            </div>

            <input type="hidden" name="reset_key" value="<?php echo isset($args['key']) ? $args['key'] : ''; ?>" />
            <input type="hidden" name="reset_login" value="<?php echo isset($args['login']) ? $args['login'] : ''; ?>" />

        <?php endif; ?>

        <div class="clear"></div>
		<center>
       	 <input type="submit" class="btn btn-default lnk-2" name="wc_reset_password" value="<?php echo 'lost_password' == $args['form'] ? __('Reset Password', 'woocommerce') : __('Save', 'woocommerce'); ?>" />
		</center>
        <?php wp_nonce_field($args['form']); ?>
		<input type="hidden" name="wc_reset_password" value="true" />
    </form>
</div>