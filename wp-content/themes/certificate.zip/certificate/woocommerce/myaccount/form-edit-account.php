<?php
/**
 * Edit account form
 *
 * @author 		WooThemes
 * @package 	WooCommerce/Templates
 * @version     2.2.7
 */
if (!defined('ABSPATH'))
    exit; // Exit if accessed directly

global $woocommerce;
?>

<?php wc_print_notices(); ?>

<div class="row mainParas zeroMarginTop zeroPaddingTop">
    <div class="account_menu_s col-md-3 col-sm-4 col-xs-12 mp">
        <h2 class="pull-left">Members Area</h2>
        <div class="clear"></div>
        <div class="tab-content popularCerts">
            <div class="tab-pane active" id="ci">
                <?php include(TEMPLATEPATH . '/membersAreaLinks.php'); ?>
            </div>
        </div>
    </div>
    <div class="col-md-9 col-sm-8 col-xs-12 mp">
        <form class="form-horizontal" role="form" action="" method="post">
            <div class="form-group reg-form">
                <div class="col-sm-offset-2 col-sm-10">
                    <h2>Customer Profile</h2>
                </div>
            </div>
            <div class="form-group reg-form">
                <label class="col-sm-2 control-label"><?php _e('First name', 'woocommerce'); ?></label>
                <div class="col-sm-10">
                    <input type="text" class="form-control" placeholder="First Name" name="account_first_name" id="account_first_name" value="<?php esc_attr_e($user->first_name); ?>">
                </div>
            </div>
            <div class="form-group reg-form">
                <label class="col-sm-2 control-label"><?php _e('Last name', 'woocommerce'); ?></label>
                <div class="col-sm-10">
                    <input type="text" class="form-control" placeholder="Last Name" name="account_last_name" id="account_last_name" value="<?php esc_attr_e($user->last_name); ?>">
                </div>
            </div>
            <div class="form-group reg-form">
                <label class="col-sm-2 control-label"><?php _e('Email address', 'woocommerce'); ?></label>
                <div class="col-sm-10">
                    <input type="email" class="form-control" placeholder="Email" name="account_email" id="account_email" value="<?php esc_attr_e($user->user_email); ?>">
                </div>
            </div>
            <div class="form-group reg-form">
                <label class="col-sm-2 control-label"><?php _e('Password (leave blank to leave unchanged)', 'woocommerce'); ?></label>
                <div class="col-sm-10">
                    <input type="password" class="form-control" placeholder="Password" name="password_2" id="password_2">
                </div>
            </div>
            <div class="form-group reg-form">
                <label class="col-sm-2 control-label"><?php _e('Confirm new password', 'woocommerce'); ?></label>
                <div class="col-sm-10">
                    <input type="password" class="form-control" placeholder="Confirm new password" name="password_2" id="password_2">
                </div>
            </div>
            <div class="form-group reg-form">
                <div class="col-sm-offset-2 col-sm-10">
                    <input type="submit" class="btn btn-default lnk-2" name="save_account_details" value="<?php _e('Save changes', 'woocommerce'); ?>" />
                    <?php wp_nonce_field('save_account_details'); ?>
                    <input type="hidden" name="action" value="save_account_details" />
                </div>
            </div>
        </form>
    </div>
</div>

<script>
    $ = jQuery;
    $(document).ready(function() {
        $('.cProfile').addClass('active');
    });
</script>    