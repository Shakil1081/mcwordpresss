<?php session_start();
/**
 * The Template for displaying all single products.
 *
 * Override this template by copying it to yourtheme/woocommerce/single-product.php
 *
 * @author 		WooThemes
 * @package 	WooCommerce/Templates
 * @version     1.6.4
 */
if (!defined('ABSPATH'))
    exit; // Exit if accessed directly

get_header('shop');
global $post, $product;
while (have_posts()) : the_post();
    ?>
	 	<?php global $post;
$terms = get_the_terms( $post->ID, 'product_cat' );
foreach ($terms as $term) {
    $product_cat_id = $term->term_id;
	$_SESSION['cat'] = $product_cat_id;
	
	  $product_cat_name = $term->name; 
	$_SESSION['catname'] = $product_cat_name;
    break;
} ?>
		<div class="clr"></div>
			<div class="bg vendor-bg">
				<form method="get" action="<?php echo get_page_link(get_post_using_slug('search-exams')); ?>" onsubmit="if(this.s.value == '' || this.s.value == 'Enter Exam Code ...'){ alert('Kindly type something in Search field');return false;}">
        	
					<div id="top_search">
					<input type="text" name="word" placeholder="Enter Exam Code"/>
					<input type="submit" name="submit" value="" id="top_search_button"/>
				</div>
	        	</form>
			</div>
		<div class="clr"></div>
		<div class="content-exams">
			<div class="inner">
				<?php
		        $args = array(
		            'wrap_before' => '<ol class="breadcrumb">',
		            'wrap_after' => '</ol>',
		            'before' => '<li>',
		            'after' => '</li>',
		            'delimiter' => '<li class="del">></li>',
		        );
		        woocommerce_breadcrumb($args);
		        do_action('woocommerce_before_single_product');
		        ?>
			</div>
			<div class="clr"></div>
			<div class="product">
				<div class="inner">
					<div class="product-top">
						<div class="product-logo">
							
							<div class="logo-prod">
								<div class="price"><center><p><?php echo $product->get_price_html(); ?></p></center></div>
							</div>
							
							<div class="stars-rating">
								<?php
			                    if (function_exists('wp_gdsr_render_article')) {
			                        wp_gdsr_render_article();
			                    }
			                    ?>
								<div class="clr"></div>
							</div>
						</div>
						<div class="product-description">
						
							<h1><?php echo get_post_meta(get_the_ID(), 'vendor_name', true); ?> <?php the_title(); ?> Exam</h1>
							<table>
								<tr>
									<th>Full Exam Name: </th>
									<td><?php echo get_post_meta(get_the_ID(), 'exam_full_name', true); ?></td>
								</tr>
								<tr>
									<th>Vendor Name: </th>
									<td><?php echo get_post_meta(get_the_ID(), 'vendor_name', true); ?></td>
								</tr>
								<tr>
									<th>Exam Code:</th>
									<td><?php the_title(); ?></td>
								</tr>
								<tr>
									<th>Questions with Answers (PDF)</th>
									<td><?php echo get_post_meta(get_the_ID(), 'questions_number', true); ?></td>
								</tr>
								<tr>
									<th>Last Updated:</th>
									<td><?php echo get_the_date('M d, Y'); ?></td>
								</tr>
							</table>
							<div class="buttons-product">
								<?php if ($product->is_purchasable()): ?>
		                            <?php if ($product->is_in_stock()) : ?>
		
		                                <?php do_action('woocommerce_before_add_to_cart_form'); ?>
		
		                                <form method="post" enctype='multipart/form-data' style="display:block; float:left;">
		                                    <?php do_action('woocommerce_before_add_to_cart_button'); ?>
		                                    <input type="hidden" name="add-to-cart" value="<?php echo esc_attr($product->id); ?>" />
		                                    
											<button type="submit" class="add-to-cart"><h5>Add to Cart</h5></button>
		                                    <?php do_action('woocommerce_after_add_to_cart_button'); ?>
		                                </form>
		                                <?
		                                if (get_post_meta(get_the_ID(), 'demo_file', TRUE)) {
		                                ?>
											<a href="<?php echo get_bloginfo('template_url') . '/downloadDemo.php/?id=' . get_the_ID(); ?>"><button class="download-demo"><h5>Download Demo</h5></button></a>
										<? } ?>
		                                <?php do_action('woocommerce_after_add_to_cart_form'); ?>
		
		                            <?php endif; ?>
		                        <?php endif; ?>
							</div>
						</div>
					</div>
				<div class="clr"></div>
				<div class="product-bottom">
				<h2><?php the_title(); ?> Product Features</h2>
				<?php
                $prodCats = get_the_terms(get_the_ID(), 'product_cat');
                $prodCat = null;
                foreach ($prodCats as $cat) {
                    $prodCat = $cat;
                    break;
                }
                $topCat = null;
                if ($prodCat) {
                    $topCat = get_term_by('id', $prodCat->parent, 'product_cat');
                }
                if ($post->post_excerpt) {
                    echo apply_filters('woocommerce_short_description', $post->post_excerpt);
                } else {
                    $defaultFeatures = get_option('exam_features');
                    if ($prodCat)
                        $defaultFeatures = str_replace("{%V-name%}", $topCat->name, $defaultFeatures);
                    if ($topCat)
                        $defaultFeatures = str_replace("{%Cert-name%}", $prodCat->name, $defaultFeatures);
                    $defaultFeatures = str_replace("{%Exam code%}", get_the_title(), $defaultFeatures);
                    $defaultFeatures = str_replace("{%Exam-name%}", get_post_meta(get_the_ID(), 'exam_full_name', true), $defaultFeatures);
                    echo "<ul><li>".substr(str_replace("</br>","</li><li>",$defaultFeatures),0,-5)."</ul>";
                    
                }
                ?>
                <?php
                if (get_the_content()) {
                    the_content();
                } else {
                    $defaultDesc = get_option('examn_description');
                    if ($prodCat)
                        $defaultDesc = str_replace("{%V-name%}", $topCat->name, $defaultDesc);
                    if ($topCat)
                        $defaultDesc = str_replace("{%Cert-name%}", $prodCat->name, $defaultDesc);
                    $defaultDesc = str_replace("{%Exam code%}", get_the_title(), $defaultDesc);
                    $defaultDesc = str_replace("{%Exam-name%}", get_post_meta(get_the_ID(), 'exam_full_name', true), $defaultDesc);


                    $defaultDesc = str_replace('[recent_exams]', "", $defaultDesc);
                    echo $defaultDesc;
                }
                ?>
			</div>
		</div>
	</div>
	<div class="clr"></div>
</div>
<div class="clr"></div>

        <?php
        do_action('woocommerce_after_single_product');
        ?>
		<!-- Updated Exams -->
		<div class="updated-exams releases">
			<div class="buttons">
				<div class="inner">
					<h5>New <?php echo $_SESSION['catname']; ?> Releases</h5>
					<?php /*?><div class="tab">
						<?php
	                    //get latest cat exams
	                    $latestExams = new WP_Query(array(
	                        'posts_per_page' => 24,
	                        'post_type' => 'product',
	                        'tax_query' => array(
	                            array(
	                                'taxonomy' => 'product_cat',
	                                'field' => 'slug',
	                                'terms' => $topCat->slug
	                            )
	                        )
	                    ));
	                    $index = 0;
	                    ?>
	                    <ul>
	                        <?php while ($latestExams->have_posts()):$latestExams->the_post(); ?>
	                            <li><a href="<?php the_permalink(); ?>"><?php the_title(); ?></br><span><?php echo get_the_date('M d, Y'); ?></span></a></li>
	                            <?php
	                        endwhile;
	                        wp_reset_query();
	                        ?>
	                        <div class="clr"></div>
	                    </ul>
					</div><?php */?>
	<div class="tab">
<?php
add_shortcode( 'bestselling_product_categories', 'sp_bestselling_products' );
function sp_bestselling_products($atts){
global $woocommerce_loop;
extract(shortcode_atts(array(
'cats' => '',	
'tax' => 'product_cat',	
'per_cat' => '3',	
'columns' => '3',	
), $atts));
if(empty($cats)){
$terms = get_terms( 'product_cat', array('hide_empty' => true, 'fields' => 'ids'));
$cats = implode(',', $terms);
}
$cats = explode(',', $cats);
if(empty($cats)){
return '';
}
ob_start();
foreach($cats as $cat){
// get the product category
$term = get_term( $cat, $tax);
// setup query
$args = array(
'post_type' 			=> 'product',
'post_status' 			=> 'publish',
'ignore_sticky_posts'   => 1,
'posts_per_page'		=> $per_cat,			
'meta_key' 		 		=> '',
'orderby' 		 		=> 'desc',
'tax_query' => array(				
array(
'taxonomy' => $tax,
'field' => 'id',
'terms' => $cat,
)
),
'meta_query' 			=> array(
array(
'key' 		=> '_visibility',
'value' 	=> array( 'catalog', 'visible' ),
'compare' 	=> 'IN'
)
)
);
// set woocommerce columns
$woocommerce_loop['columns'] = $columns;
// query database
$products = new WP_Query( $args );
$woocommerce_loop['columns'] = $columns;
if ( $products->have_posts() ) : ?>
<?php woocommerce_product_loop_start(); ?>
<ul>
<?php while ( $products->have_posts() ) : $products->the_post(); ?>
<li><a href="<?php the_permalink(); ?>"><?php the_title(); ?></br><span><?php echo get_the_date('M d, Y'); ?></span></a></li>
<?php
endwhile;
?>
<div class="clr"></div>
</ul>
<?php //woocommerce_get_template_part( 'content', 'product' ); ?>
<?php //endwhile; // end of the loop. ?>
<?php woocommerce_product_loop_end(); ?>
<?php endif;
wp_reset_postdata();
}
return '<div class="woocommerce columns-' . $columns . '">' . ob_get_clean() . '</div>';
}
?>
<?php echo do_shortcode('[bestselling_product_categories cats="'.$_SESSION['cat'].'" per_cat="30"]'); ?>
</div>				
					
					
					
					
					
					
				</div>
			</div>
			<div class="buttons">
				<div class="inner">
					<h5>Updated <?php echo $_SESSION['catname']; ?> Exams</h5>
					<?php /*?><div class="tab">
                        <?php
	                    //get updated cat exams
	                    $latestExams = new WP_Query(array(
	                        'posts_per_page' => 24,
	                        'post_type' => 'product',
	                        'orderby' => 'modified',
	                        'order' => 'desc',
	                        'tax_query' => array(
	                            array(
	                                'taxonomy' => 'product_cat',
	                                'field' => 'slug',
	                                'terms' => $topCat->slug
	                            )
	                        )
	                    ));
	                    ?>
	                    <ul>
	                        <?php while ($latestExams->have_posts()):$latestExams->the_post(); ?>
	                        	<li><a href="<?php the_permalink(); ?>"><?php the_title(); ?></br><span><?php echo get_the_date('M d, Y'); ?></span></a></li>
	                        <?php
	                    endwhile;
	                    wp_reset_query();
	                    ?>
	                    	<div class="clr"></div>
	                    </ul>
					</div><?php */?>
					
		<div class="tab">
<?php
add_shortcode( 'latest_product_categories', 'sp_latest_products' );
function sp_latest_products($atts){
global $woocommerce_loop;
extract(shortcode_atts(array(
'cats' => '',	
'tax' => 'product_cat',	
'per_cat' => '3',	
'columns' => '3',	
), $atts));
if(empty($cats)){
$terms = get_terms( 'product_cat', array('hide_empty' => true, 'fields' => 'ids'));
$cats = implode(',', $terms);
}
$cats = explode(',', $cats);
if(empty($cats)){
return '';
}
ob_start();
foreach($cats as $cat){
// get the product category
$term = get_term( $cat, $tax);
// setup query
$args = array(
'post_type' 			=> 'product',
'post_status' 			=> 'publish',
'ignore_sticky_posts'   => 1,
'posts_per_page'		=> $per_cat,			
'meta_key' 		 		=> 'total_sales',
'orderby' 		 		=> 'meta_value_num',
'tax_query' => array(				
array(
'taxonomy' => $tax,
'field' => 'id',
'terms' => $cat,
)
),
'meta_query' 			=> array(
array(
'key' 		=> '_visibility',
'value' 	=> array( 'catalog', 'visible' ),
'compare' 	=> 'IN'
)
)
);
// set woocommerce columns
$woocommerce_loop['columns'] = $columns;
// query database
$products = new WP_Query( $args );
$woocommerce_loop['columns'] = $columns;
if ( $products->have_posts() ) : ?>
<?php woocommerce_product_loop_start(); ?>
<ul>
<?php while ( $products->have_posts() ) : $products->the_post(); ?>
<li><a href="<?php the_permalink(); ?>"><?php the_title(); ?></br><span><?php echo get_the_date('M d, Y'); ?></span></a></li>
<?php
endwhile;
?>
<div class="clr"></div>
</ul>
<?php //woocommerce_get_template_part( 'content', 'product' ); ?>
<?php //endwhile; // end of the loop. ?>
<?php woocommerce_product_loop_end(); ?>
<?php endif;
wp_reset_postdata();
}
return '<div class="woocommerce columns-' . $columns . '">' . ob_get_clean() . '</div>';
}
?>
<?php echo do_shortcode('[latest_product_categories cats="'.$_SESSION['cat'].'" per_cat="30"]'); ?>
</div>			
					
					
					
					
				</div>
			</div>
		</div>
		<div class="clr"></div>
        <?php
    endwhile;
    get_footer('shop');
    ?>