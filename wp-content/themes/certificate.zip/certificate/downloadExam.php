<?php

require_once dirname(__FILE__) . '/../../../wp-load.php';
if (isset($_GET['orderId']) && isset($_GET['examId']) && $_GET['orderId'] && $_GET['examId']) {
    //check if loggedin
    if (is_user_logged_in()) {
        //get the exam
        $exam = get_post($_GET['examId']);
        //get the order
        $order = new WC_Order($_GET['orderId']);
        if ($exam && $order) {
            //chk if the user is the owner
            $userId = get_post_meta($_GET['orderId'], '_customer_user', true);
            if (get_current_user_id() == $userId) {
                //chk if order not expired
                $orderDate = new DateTime($order->order_date);
                $expireDate = $orderDate->modify('+' . get_option('exam_download_time', 90) . ' day');
                if ($expireDate > new DateTime()) {
                    //get the exam file
                    if (get_post_meta($_GET['examId'], 'exam_file', true)) {
                        //log the download
                        global $wpdb;
                        $downloadExamsHistoryTable = $wpdb->prefix . "download_exam_history";
                        $wpdb->insert($downloadExamsHistoryTable, array(
                            'user_id' => get_current_user_id(),
                            'order_id' => $_GET['orderId'],
                            'exam_id' => $_GET['examId'],
                            'createdAt' => current_time('mysql')
                        ));

                        $fileObject = get_post(get_post_meta($_GET['examId'], 'exam_file', true));
                        $filePath = $fileObject->guid;

                        //download the file
                        header("Content-Description: File Transfer");
                        header("Content-Type: application/octet-stream");
                        header("Content-Disposition: attachment; filename=\"".basename($filePath)."\"");
                        readfile($filePath);
                    } else {
                        echo 'error1';
                    }
                } else {
                    echo 'error2';
                }
            } else {
                echo 'error3';
            }
        } else {
            echo 'error4';
        }
    } else {
        echo 'error5';
    }
} else {
    echo 'error6';
}
?>