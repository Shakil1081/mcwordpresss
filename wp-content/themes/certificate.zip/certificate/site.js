jQuery(document).ready(function($){
	$(".slider .right").click(function(){
		$current_slide += 1;
		
		if($(".slider_inner div").eq($current_slide).length == 0) {
			$current_slide = 0;
		}
		
		$diff_width = "-" + ($current_slide * 929)+"px";
		
		$( ".slider_inner" ).animate({
			 "margin-left": $diff_width
		}, 1000);
		return false;
	});
	
	$(".slider .left").click(function(){
		$current_slide -= 1;
		if($current_slide < 0) {
			$current_slide = 4;
		}
		
		$diff_width = "-" + ($current_slide * 929)+"px";
		$( ".slider_inner" ).animate({
			 "margin-left": $diff_width
		}, 1000);
		return false;
	});
	
	
	$current_slide = 0;
	function slider_init() {
	
		$current_slide += 1;
		
		if($(".slider_inner div").eq($current_slide).length == 0) {
			$current_slide = 0;
		}
		
		$diff_width = "-" + ($current_slide * 929)+"px";
		
		$( ".slider_inner" ).animate({
			 "margin-left": $diff_width
		}, 1000);
						
		setTimeout(slider_init,7000);
	}
	slider_init();
	
	$("#popular_tabs div").click(function(){
		$current_index_pop = $(this).parent().find(".active").index();
		console.log($current_index_pop);
		$(this).parent().find(".active").removeClass("active");
		
		$("#popular_tabs_tabs .tab").eq($current_index_pop).addClass("hidden_tab");
		
		$new_index_pop = $(this).index();
		console.log($new_index_pop);
		$("#popular_tabs_tabs .tab").eq($new_index_pop).removeClass("hidden_tab");
		
		$(this).addClass("active");
		
		return false;
	});
	
	$("#certifications_tabs div").click(function(){
		$current_index_cert = $(this).parent().find(".active").index()-1;
		
		$(this).parent().find(".active").removeClass("active");
		
		$("#certifications_tabs_tabs .inner").eq($current_index_cert).addClass("hidden_tab");
		
		$new_index_cert = $(this).index();
		
		$("#certifications_tabs_tabs .inner").eq($new_index_cert).removeClass("hidden_tab");
		
		$(this).addClass("active");
		
		return false;
	});
});