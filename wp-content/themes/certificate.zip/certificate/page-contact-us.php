<?php
get_header();
the_post();
?>
	<div class="clr"></div>
    <div class="bg vendor-bg">
    	<form method="get" action="<?php echo get_page_link(get_post_using_slug('search-exams')); ?>" onsubmit="if(this.s.value == '' || this.s.value == 'Enter Exam Code ...'){ alert('Kindly type something in Search field');return false;}">
    	
			<div id="top_search">
					<input type="text" name="word" placeholder="Enter Exam Code"/>
					<input type="submit" name="submit" value="" id="top_search_button"/>
				</div>
    	</form>
    	</div>
	</div>
    <div class="inner">
    	<br/>
        <ol class="breadcrumb">
            <li><a href="<?php echo home_url(); ?>">Home</a></li>
            <li class="del">></li>
            <li class="active"><?php the_title(); ?></li>
        </ol>
        <br/><br/>
        <div class="clr"></div>
    </div>
    <div class="inner mainParas">
        <?php the_content(); ?>
        <div class="clr"></div>
    </div>
    <script>
        $ = jQuery;
        $(document).ready(function() {
            $('.wpcf7-form').addClass('form-horizontal');
        });
    </script>
    <?php get_footer(); ?>