<?php
/*
  Template Name: Search
 */
get_header();
?>
	<div class="clr"></div>
        <div class="bg vendor-bg">
        	<form method="get" action="<?php echo get_page_link(get_post_using_slug('search-exams')); ?>" onsubmit="if(this.s.value == '' || this.s.value == 'Enter Exam Code ...'){ alert('Kindly type something in Search field');return false;}">
        	
				<div id="top_search">
					<input type="text" name="word" placeholder="Enter Exam Code"/>
					<input type="submit" name="submit" value="" id="top_search_button"/>
				</div>
        	</form>
    	</div>
	</div>
	<div class="content-exams">
		<div class="inner">
	        <ol class="breadcrumb">
	            <li><a href="<?php echo home_url(); ?>">Home</a></li>
	            <li class="del">></li>
	            <li class="active">Search results for "<?php echo $_GET['word']; ?>"</li>
	        </ol>
		</div>
    </div>
    <div class="clr"></div>
    <!-- Updated Exams -->
	<div class="updated-exams releases">
    <?php
    if (!empty($_GET['word'])):
        $searchWord = $_GET['word'];
        $termTable = $wpdb->terms;
        $termTaxonomyTable = $wpdb->term_taxonomy;
        $categories = $wpdb->get_results("select t.* from $termTable t join $termTaxonomyTable tt on t.term_id = tt.term_id where tt.taxonomy = 'product_cat' and t.name like '%$searchWord%'");

        if ($categories):
        	?>
        	<div class="buttons">
				<div class="inner">
					<h5>Categories</h5>
					<div class="tab">
	                    <ul>
							<?
							foreach ($categories as $category):
								$catObject = get_term($category->term_id, 'product_cat');
								?>
									<li>
										<a href="<?php echo get_term_link($catObject, 'product_cat'); ?>">
											<?php echo $category->name; ?>
											</br>
										</a>
									</li>
								<?php
							endforeach;
							?>	                       
	                        <div class="clr"></div>
	                    </ul>
					</div>
				</div>
			</div>
        	<div class="clr"></div>
            <?
        endif;
        
        
        $exams = new WP_Query(array(
            'posts_per_page' => -1,
            'post_type' => 'product',
            's' => $searchWord
        ));
        if ($exams->have_posts()):
            $sreachResults = TRUE;
            ?>
            <div class="buttons">
				<div class="inner">
					<h5>Exams</h5>
					<div class="tab">
	                    <ul>
							<?php while ($exams->have_posts()):$exams->the_post(); ?>
				            	<li><a href="<?php the_permalink(); ?>"><?php the_title(); ?></br><span><?php echo get_the_date('M d, Y'); ?></span></a></li>
				                <?php
				            endwhile;
				            wp_reset_query();
				            ?>	                       
	                        <div class="clr"></div>
	                    </ul>
					</div>
				</div>
			</div>
        	<div class="clr"></div>
        	
        	
            
        <?
        endif;
        ?>
        <?php if (!$categories && !$exams->have_posts()): ?>
            <div class="inner"><h3>No results found.</h3><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/></div>
        <?php endif; ?>

    <?php endif; ?>
    </div>
	<div class="clr"></div>
    <?php get_footer(); ?>