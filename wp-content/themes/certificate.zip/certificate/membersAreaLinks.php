<ul class="list-group">
    <li class="list-group-item lastElement cProfile"><i class="fa fa-angle-double-right"></i><a href="<?php echo wc_customer_edit_account_url(); ?>"> Customer Profile</a></li>  
    <li class="list-group-item oHistory"><i class="fa fa-angle-double-right"></i><a href="<?php echo get_page_link(get_post_using_slug('orders')); ?>"> Order History</a></li>
    <li class="list-group-item dHistory"><i class="fa fa-angle-double-right"></i><a href="<?php echo get_page_link(get_post_using_slug('download-history')); ?>"> Download History</a></li>
</ul>