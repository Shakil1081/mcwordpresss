<?php

require_once dirname(__FILE__) . '/../../../wp-load.php';
if (isset($_GET['id']) && $_GET['id']) {
    $exam = get_post($_GET['id']);
    if ($exam) {
        if (get_post_meta($_GET['id'], 'demo_file', true)) {
            if (is_user_logged_in()) {
                //log the download
                global $wpdb;
                $downloadExamsHistoryTable = $wpdb->prefix . "download_exam_history";
                $wpdb->insert($downloadExamsHistoryTable, array(
                    'user_id' => get_current_user_id(),
                    'order_id' => 0,
                    'exam_id' => $_GET['id'],
                    'demo' => true,
                    'createdAt' => current_time('mysql')
                ));
            }

            $fileObject = get_post(get_post_meta($_GET['id'], 'demo_file', true));
            $filePath = $fileObject->guid;

            //download the file
            header("Content-Description: File Transfer");
            header("Content-Type: application/octet-stream");
            header("Content-Disposition: attachment; filename=\"" . basename($filePath) . "\"");
            readfile($filePath);
        } else {
            echo 'error1';
        }
    } else {
        echo 'error2';
    }
} else {
    echo 'error3';
}
?>