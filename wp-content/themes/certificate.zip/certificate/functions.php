<?php
@ini_set( 'upload_max_size' , '64M' );
@ini_set( 'post_max_size', '64M');
@ini_set( 'max_execution_time', '300' );
add_theme_support('post-thumbnails');
add_post_type_support('page', 'excerpt');

add_filter('wp_mail_content_type', 'set_html_content_type');
wp_enqueue_script("site",str_replace(array("http:", "https:"), "", get_stylesheet_directory_uri())."/site.js", array("jQuery"),1);

function set_html_content_type() {
    return 'text/html';
}
add_filter( 'woocommerce_billing_fields', 'custom_woocommerce_billing_fields' );

function custom_woocommerce_billing_fields( $fields ) {

   unset($fields['billing_phone']);
   unset($fields['billing_address_1']);
   unset($fields['billing_address_2']);
   unset($fields['billing_city']);
   unset($fields['billing_state']);
   unset($fields['billing_postcode']);
   
 return $fields;
}
//add flag if product has demo file or full file
add_action("save_post", "save_edutronics_posts_details");

function save_edutronics_posts_details($post_id) {
    global $post;
    if ($_POST['post_type'] == "product") {
        if (get_post_meta($post_id, 'exam_file', TRUE)) {
            update_post_meta($post_id, 'exam_file_flag', 'yes');
        } else {
            update_post_meta($post_id, 'exam_file_flag', 'no');
        }

        if (get_post_meta($post_id, 'demo_file', TRUE)) {
            update_post_meta($post_id, 'demo_file_flag', 'yes');
        } else {
            update_post_meta($post_id, 'demo_file_flag', 'no');
        }
    }
}

/**
 * Filter products by type
 *
 * @access public
 * @return void
 */
function wpa104537_filter_products_by_downloadable_status() {

    global $typenow, $wp_query;

    if ($typenow == 'product') {


        // exam file filter
        $output .= "<select name='download_status' id='dropdown_featured_status'>";
        $output .= '<option value="">' . __('Exam File', 'woocommerce') . '</option>';

        $output .="<option value='has_exam_file' ";
        if (isset($_GET['download_status']))
            $output .= selected('has_exam_file', $_GET['download_status'], false);
        $output .=">" . __('Has Exam File', 'woocommerce') . "</option>";

        $output .="<option value='no_exam_file' ";
        if (isset($_GET['download_status']))
            $output .= selected('no_exam_file', $_GET['download_status'], false);
        $output .=">" . __('No Exam File', 'woocommerce') . "</option>";

        $output .="</select>";

        // demo file filter
        $output .= "<select name='demo_status' id='dropdown_featured_status'>";
        $output .= '<option value="">' . __('Demo File', 'woocommerce') . '</option>';

        $output .="<option value='has_demo_file' ";
        if (isset($_GET['demo_status']))
            $output .= selected('has_demo_file', $_GET['demo_status'], false);
        $output .=">" . __('Has Demo File', 'woocommerce') . "</option>";

        $output .="<option value='no_demo_file' ";
        if (isset($_GET['demo_status']))
            $output .= selected('no_demo_file', $_GET['demo_status'], false);
        $output .=">" . __('No Demo File', 'woocommerce') . "</option>";

        $output .="</select>";

        echo $output;
    }
}

add_action('restrict_manage_posts', 'wpa104537_filter_products_by_downloadable_status');

/**
 * Filter the products in admin based on options
 *
 * @access public
 * @param mixed $query
 * @return void
 */
function wpa104537_featured_products_admin_filter_query($query) {
    global $typenow, $wp_query;

    if ($typenow == 'product') {
        // Subtypes
        if (!empty($_GET['download_status'])) {
            if ($_GET['download_status'] == 'has_exam_file') {
                $query->query_vars['meta_value'] = 'yes';
                $query->query_vars['meta_key'] = 'exam_file_flag';
            } elseif ($_GET['download_status'] == 'no_exam_file') {
                $query->query_vars['meta_value'] = 'no';
                $query->query_vars['meta_key'] = 'exam_file_flag';
            }
        }

        if (!empty($_GET['demo_status'])) {
            if ($_GET['demo_status'] == 'has_demo_file') {
                $query->query_vars['meta_value'] = 'yes';
                $query->query_vars['meta_key'] = 'demo_file_flag';
            } elseif ($_GET['demo_status'] == 'no_demo_file') {
                $query->query_vars['meta_value'] = 'no';
                $query->query_vars['meta_key'] = 'demo_file_flag';
            }
        }
    }
}

add_filter('parse_query', 'wpa104537_featured_products_admin_filter_query');

/* Runs when theme is activated */
add_action('init', 'certificate_install');

function certificate_install() {
    global $wpdb;

    //create newsletter table
    $tbl_name = $wpdb->prefix . 'download_exam_history';
    //check if not exist
    if ($wpdb->get_var("show tables like '$tbl_name'") != $tbl_name) {
        $sql = "CREATE TABLE " . $tbl_name . " (
                    id INT NOT NULL AUTO_INCREMENT,
                    exam_id INT NOT NULL,
                    order_id INT NOT NULL,
                    user_id INT NOT NULL,
                    demo BOOLEAN default 0,
                    createdAt DATETIME NOT NULL,
                    UNIQUE KEY id(id)
                );";

        $wpdb->query($sql);
    }

    $check = get_option('theme_certificate_activation_check');
    if ($check != "set") {
        $catTableName = $wpdb->prefix . 'terms';
        $sql = "ALTER TABLE $catTableName ADD `is_popular` BOOLEAN default 0, ADD `is_top_certificat` BOOLEAN default 0";
        $wpdb->query($sql);
        // Add marker so it doesn't run in future
        add_option('theme_certificate_activation_check', "set");
    }
}

//woocommerce settings
add_theme_support('woocommerce');

// Add the fields to the "product_cat" taxonomy, using our callback function  
add_action('product_cat_edit_form_fields', 'product_cat_taxonomy_custom_fields', 10, 2);

function product_cat_taxonomy_custom_fields($cat) {
    if ($cat->parent == 0):
        ?>  
        <tr class="form-field">  
            <th scope="row" valign="top">  
                <label for="is_popular"><?php _e('Is Popular'); ?></label>  
            </th>  
            <td>  
                <input type="checkbox" name="cat_is_popular" id="is_popular" value="1" <?php if ($cat->is_popular == true): ?>checked=""<?php endif; ?>/>            
            </td>  
        </tr>      
        <?php
    endif;
    //check if sub cat
    if ($cat->parent != 0):
        ?>
        <tr class="form-field">  
            <th scope="row" valign="top">  
                <label for="is_top_certificat"><?php _e('Is Top Certificat'); ?></label>  
            </th>  
            <td>  
                <input type="checkbox" name="cat_is_top_certificat" id="is_top_certificat" value="1" <?php if ($cat->is_top_certificat == true): ?>checked=""<?php endif; ?>/>            
            </td>  
        </tr>
        <?php
    endif;
}

// Save the changes made on the "presenters" taxonomy, using our callback function  
add_action('edited_product_cat', 'save_taxonomy_custom_fields', 10, 2);

// A callback function to save our extra taxonomy field(s)  
function save_taxonomy_custom_fields($term_id) {
    global $wpdb;
    $catTableName = $wpdb->prefix . 'terms';
    if (isset($_POST['cat_is_popular'])) {
        $wpdb->update($catTableName, array(
            'is_popular' => true
                ), array('term_id' => $term_id));
    } else {
        $wpdb->update($catTableName, array(
            'is_popular' => false
                ), array('term_id' => $term_id));
    }

    if (isset($_POST['cat_is_top_certificat'])) {
        $wpdb->update($catTableName, array(
            'is_top_certificat' => true
                ), array('term_id' => $term_id));
    } else {
        $wpdb->update($catTableName, array(
            'is_top_certificat' => false
                ), array('term_id' => $term_id));
    }
}

/**
 * this function used to get post by itis slug
 * @param string $slug
 * @author ahmed
 */
function get_post_using_slug($slug) {
    global $wpdb;
    $request = $wpdb->get_row("SELECT * FROM $wpdb->posts WHERE post_name = '$slug' and post_status = 'publish'");
    return $request;
}

//change login logo
function my_custom_login_logo() {
    echo '<style type="text/css">
        h1 a { background:url(' . get_bloginfo('template_directory') . '/screenshot.png) no-repeat center !important;width:225px !important;height: 90px !important; }
    </style>';
}

add_action('login_head', 'my_custom_login_logo');

add_action('init', 'register_my_menus');

/**
 * this function used to register theme menus
 * @author Ahmed
 */
function register_my_menus() {
    register_nav_menus(
            array(
                'header-menu' => __('Header Menu'),
                'sub-header-menu' => __('Sub Header Menu'),
                'footer-menu' => __('Footer Menu')
            )
    );
}

add_action('init', 'create_my_post_type');

function create_my_post_type() {
    register_post_type('slider', array(
        'labels' => array(
            'name' => __('Slider'),
            'singular_name' => __('Slider'),
            'add_new_item' => __('Add Slider Item')
        ),
        'public' => true,
        'has_archive' => TRUE,
        'show_ui' => true,
        'show_in_admin_bar' => true,
        'supports' => array('thumbnail', 'title', 'page-attributes'),
        'map_meta_cap' => true,
        'hierarchical' => true,
        'show_in_nav_menus' => true,
        'menu_position' => 6,
        'rewrite' => array('slug' => 'slider', 'with_front' => FALSE)
            )
    );

    register_post_type('testimonial', array(
        'labels' => array(
            'name' => __('Testimonial'),
            'singular_name' => __('Testimonial'),
            'add_new_item' => __('Add Testimonial Item')
        ),
        'public' => true,
        'has_archive' => TRUE,
        'show_ui' => true,
        'show_in_admin_bar' => true,
        'supports' => array('thumbnail', 'title', 'editor'),
        'map_meta_cap' => true,
        'hierarchical' => true,
        'show_in_nav_menus' => true,
        'menu_position' => 7,
        'taxonomies' => array('product_cat'),
        'rewrite' => array('slug' => 'testimonial', 'with_front' => FALSE)
            )
    );
}

/* * **************************** theme settings ****************************************** */
if (is_admin()) {

    /* Call the html code */
    add_action('admin_menu', 'site_settings');

    function site_settings() {
        add_menu_page('Certificate Settings', 'Certificate Settings', 'administrator', 'certificate-settings', 'certificate_settings_function');
        add_menu_page('Default Content', 'Default Content', 'administrator', 'default-content', 'default_content_function');
    }

}

function default_content_function() {
    ?>
    <div class="wrap">
        <div id="icon-tools" class="icon32"></div>
        <h2>Default Content</h2>
        <?php
        if (isset($_GET['settings-updated']) && $_GET['settings-updated'] == 'true'):
            ?>
            <div class="updated below-h2" id="message">
                <p>Settings Updated.</p>
            </div>
        <?php endif; ?>
        <form method="post" action="options.php">
            <?php wp_nonce_field('update-options'); ?>
            <table class="widefat" style="margin-top: 20px;">
                <tbody>
                    <tr><th></th><th><strong style="color: #990000;font-size: 12px;font-weight: bold;padding: 5px;">{%V-name%} {%Cert-name%} {%Exam code%} {%Exam-name%}</strong></th></tr>
                    <tr>
                        <td style="width: 15%;">Vendor Content</td>
                        <td>
                            <?php
                            $contentValue = get_option('vendor_description');
                            wp_editor(html_entity_decode(stripcslashes($contentValue)), 'vendor_description', $settings = array('textarea_name' => 'vendor_description', 'textarea_rows' => 10));
                            ?>
                        </td>
                    </tr>
                    <tr>
                        <td>Vendor meta title</td>
                        <td>
                            <?php
                            $contentValue = get_option('vendor_title');
                            ?> 
                            <input type="text" value="<?php echo $contentValue; ?>" name="vendor_title" />
                        </td>
                    </tr>
                    <tr>
                        <td>Vendor meta description</td>
                        <td>
                            <?php
                            $contentValue = get_option('vendor_meta_desc');
                            ?> 
                            <textarea cols="45" rows="4" name="vendor_meta_desc"><?php echo $contentValue; ?></textarea>

                        </td>
                    </tr>
                    <tr>
                        <td>Vendor meta Keywords</td>
                        <td>
                            <?php
                            $contentValue = get_option('vendor_meta_keywords');
                            ?> 
                            <input type="text" value="<?php echo $contentValue; ?>" name="vendor_meta_keywords" />

                        </td>
                    </tr>
                    <tr>
                        <td colspan="2"><hr/></td>
                    </tr>
                    <tr>
                        <td style="width: 15%;">Certification Content</td>
                        <td>
                            <?php
                            $contentValue = get_option('certification_description');
                            wp_editor(html_entity_decode(stripcslashes($contentValue)), 'certification_description', $settings = array('textarea_name' => 'certification_description', 'textarea_rows' => 10));
                            ?>
                        </td>
                    </tr>
                    <tr>
                        <td>Certificate meta title</td>
                        <td>
                            <?php
                            $contentValue = get_option('certification_title');
                            ?> 
                            <input type="text" value="<?php echo $contentValue; ?>" name="certification_title" />
                        </td>
                    </tr>
                    <tr>
                        <td>Certificate meta description</td>
                        <td>
                            <?php
                            $contentValue = get_option('certification_meta_desc');
                            ?> 
                            <textarea cols="45" rows="4" name="certification_meta_desc"><?php echo $contentValue; ?></textarea>

                        </td>
                    </tr>
                    <tr>
                        <td>Certificate meta Keywords</td>
                        <td>
                            <?php
                            $contentValue = get_option('certification_keywords');
                            ?> 
                            <input type="text" value="<?php echo $contentValue; ?>" name="certification_keywords" />

                        </td>
                    </tr>
                    <tr>
                        <td colspan="2"><hr/></td>
                    </tr>
                    <tr>
                        <td style="width: 15%;">Exam Content</td>
                        <td>
                            <?php
                            $contentValue = get_option('examn_description');
                            wp_editor(html_entity_decode(stripcslashes($contentValue)), 'examn_description', $settings = array('textarea_name' => 'examn_description', 'textarea_rows' => 10));
                            ?>
                        </td>
                    </tr>
                    <tr>
                        <td style="width: 15%;">Exam Features</td>
                        <td>
                            <?php
                            $contentValue = get_option('exam_features');
                            wp_editor(html_entity_decode(stripcslashes($contentValue)), 'exam_features', $settings = array('textarea_name' => 'exam_features', 'textarea_rows' => 10));
                            ?>
                        </td>
                    </tr>
                    <tr>
                        <td>Exam meta title</td>
                        <td>
                            <?php
                            $contentValue = get_option('exam_title');
                            ?> 
                            <input type="text" value="<?php echo $contentValue; ?>" name="exam_title" />
                        </td>
                    </tr>
                    <tr>
                        <td>Exam meta description</td>
                        <td>
                            <?php
                            $contentValue = get_option('exam_meta_desc');
                            ?> 
                            <textarea cols="45" rows="4" name="exam_meta_desc"><?php echo $contentValue; ?></textarea>

                        </td>
                    </tr>
                    <tr>
                        <td>Exam meta Keywords</td>
                        <td>
                            <?php
                            $contentValue = get_option('exam_meta_keywords');
                            ?> 
                            <input type="text" value="<?php echo $contentValue; ?>" name="exam_meta_keywords" />

                        </td>
                    </tr>
                    <tr>
                        <td colspan="2"><hr/></td>
                    </tr>
                    <tr>
                        <td>Exam demo link title</td>
                        <td>
                            <?php
                            $contentValue = get_option('exam_demo_link_title');
                            ?> 
                            <input type="text" style="width: 100%;" value="<?php echo $contentValue; ?>" name="exam_demo_link_title" />

                        </td>
                    </tr>
                </tbody>
            </table>
            <input type="hidden" name="action" value="update" />
            <input type="hidden" name="page_options" value="exam_demo_link_title,examn_description,certification_description,vendor_description,vendor_title,vendor_meta_desc,vendor_meta_keywords,certification_title,certification_keywords,certification_meta_desc,exam_title,exam_meta_desc,exam_meta_keywords,exam_features" />

            <p>
                <input type="submit" class="button-primary" value="<?php _e('Save Changes') ?>" />
            </p>

        </form>

    </div>
    <?php
}

function certificate_settings_function() {
    ?>
    <div class="wrap">
        <div id="icon-tools" class="icon32"></div>
        <h2>Certificate Settings</h2>
        <?php
        if (isset($_GET['settings-updated']) && $_GET['settings-updated'] == 'true'):
            ?>
            <div class="updated below-h2" id="message">
                <p>Settings Updated.</p>
            </div>
        <?php endif; ?>
        <form method="post" action="options.php">
            <?php wp_nonce_field('update-options'); ?>
            <table class="widefat" style="margin-top: 20px;">
                <tbody>
                    <tr>
                        <td style="width: 15%;">Exam Download Time</td>
                        <td>
                            <input style="width: 70%;" name="exam_download_time" value="<?= get_option('exam_download_time'); ?>"/> Days
                        </td>
                    </tr>
                    <tr>
                        <td style="width: 15%;">Facbook Page Url</td>
                        <td>
                            <input style="width: 70%;" name="facebook_page_url" value="<?= get_option('facebook_page_url'); ?>"/>
                        </td>
                    </tr>
                    <tr>
                        <td style="width: 15%;">Twitter Page Url</td>
                        <td>
                            <input style="width: 70%;" name="twitter_page_url" value="<?= get_option('twitter_page_url'); ?>"/>
                        </td>
                    </tr>
                    <tr>
                        <td style="width: 15%;">Google+ Page Url</td>
                        <td>
                            <input style="width: 70%;" name="google_page_url" value="<?= get_option('google_page_url'); ?>"/>
                        </td>
                    </tr>
                    <tr>
                        <td style="width: 15%;">Linkedin Page Url</td>
                        <td>
                            <input style="width: 70%;" name="linkedin_page_url" value="<?= get_option('linkedin_page_url'); ?>"/>
                        </td>
                    </tr>

                    <tr><th colspan="2"><strong>Home Page</strong></th></tr>
                    <tr>
                        <td style="width: 15%;">Welcome Title</td>
                        <td>
                            <input style="width: 70%;" name="welcome_title" value="<?= get_option('welcome_title'); ?>"/>
                        </td>
                    </tr>
                    <tr>
                        <td style="width: 15%;">Welcome Body</td>
                        <td>
                            <textarea rows="5" style="width: 70%;" name="welcome_body"><?= get_option('welcome_body'); ?></textarea>                            
                        </td>
                    </tr>
                    <tr>
                        <td style="width: 15%;">Our Clients Title</td>
                        <td>
                            <input style="width: 70%;" name="our_clients_title" value="<?= get_option('our_clients_title'); ?>"/>
                        </td>
                    </tr>
                    <tr>
                        <td style="width: 15%;">Our Clients Description</td>
                        <td>
                            <textarea rows="5" style="width: 70%;" name="our_clients_desc"><?= get_option('our_clients_desc'); ?></textarea>                            
                        </td>
                    </tr>
                    <tr>
                        <td style="width: 15%;">Video Testimonials Title</td>
                        <td>
                            <input style="width: 70%;" name="video_testimonials_title" value="<?= get_option('video_testimonials_title'); ?>"/>
                        </td>
                    </tr>
                    <tr>
                        <td style="width: 15%;">Video Testimonials Description</td>
                        <td>
                            <textarea rows="5" style="width: 70%;" name="video_testimonials_desc"><?= get_option('video_testimonials_desc'); ?></textarea>                            
                        </td>
                    </tr>
                    <tr>
                        <td style="width: 15%;">Recaptcha Public Key</td>
                        <td>
                            <input style="width: 70%;" name="recaptcha_public_key" value="<?= get_option('recaptcha_public_key'); ?>"/>
                        </td>
                    </tr>
                    <tr>
                        <td style="width: 15%;">Recaptcha Private Key</td>
                        <td>
                            <input style="width: 70%;" name="recaptcha_private_key" value="<?= get_option('recaptcha_private_key'); ?>"/>
                        </td>
                    </tr>
                </tbody>
            </table>
            <input type="hidden" name="action" value="update" />
            <input type="hidden" name="page_options" value="recaptcha_public_key,recaptcha_private_key,exam_download_time,video_testimonials_title,video_testimonials_desc,our_clients_desc,our_clients_title,welcome_body,welcome_title,linkedin_page_url,google_page_url,twitter_page_url,facebook_page_url" />

            <p>
                <input type="submit" class="button-primary" value="<?php _e('Save Changes') ?>" />
            </p>

        </form>

    </div>
    <?php
}

function recent_exam_func() {
    global $wpdb;
    $data = '';
    $data .= '<div class="row examsTable">';
    $data .= '<div class="col-xs-12 zeroPadding">';
    $data .= '<ul class="nav nav-tabs">';
    $data .= '<li class="active">';
    $data .= '<a href="#px" data-toggle="tab">Popular<div class="visible-xs clear"></div> Exams</a>';
    $data .= '<img alt="" src="' . get_bloginfo('template_url') . '/images/triangle2.png" />';
    $data .= '</li>';
    $data .= '<li>';
    $data .= '<a href="#tc" data-toggle="tab"><span class="hidden-xs">Top Certifications</span><div class="visible-xs">Top <div class="clear"></div> Certs.</div></a>';
    $data .= '<img alt="" src="' . get_bloginfo('template_url') . '/images/triangle2.png" />';
    $data .= '</li>';
    $data .= '<li>';
    $data .= '<a href="#re" data-toggle="tab">Recent <div class="visible-xs clear"></div>Exams</a>';
    $data .= '<img alt="" src="' . get_bloginfo('template_url') . '/images/triangle2.png" />';
    $data .= '</li>';
    $data .= '<li>';
    $data .= '<a href="#ne" data-toggle="tab">New <div class="visible-xs clear"></div>Exams<span class="label label-danger hidden-xs">New</span></a>';
    $data .= '<img alt="" src="' . get_bloginfo('template_url') . '/images/triangle2.png" />';
    $data .= '</li>';
    $data .= '</ul>';
    $data .= ' <div class="tab-content">';
    $data .= '<div class="tab-pane active" id="px">';

    //get popular cat

    $popularCats = $wpdb->get_results("select t.* from $wpdb->terms t join $wpdb->term_taxonomy tt where tt.term_id = t.term_id and tt.taxonomy = 'product_cat' and tt.parent = 0 and t.is_popular = true order by t.name asc limit 4");
    foreach ($popularCats as $popularCat):
        $catObject = get_term_by('id', $popularCat->term_id, 'product_cat');

        $data .= '<div class="row examsRow zeroMargin">';
        $data .= '<div class="col-sm-2 col-xs-12 zeroPadding">';
        $data .= '<div class="rowHead">';

        // get the thumbnail id user the term_id
        $thumbnail_id = get_woocommerce_term_meta($popularCat->term_id, 'thumbnail_id', true);

        // get the image URL
        $image = null;
        if ($thumbnail_id)
            $image = wp_get_attachment_url($thumbnail_id);
        if ($image):

            $data .= '<img alt=" ' . $popularCat->name . '" src="' . $image . '" class="vendorIco" />';
        else:
            $data .= '<img alt=" ' . $popularCat->name . '" src="' . get_bloginfo('template_url') . '/images/icon.png" class="vendorIco" />';
        endif;
        $data .= '<img alt="' . $popularCat->name . '" src="' . get_bloginfo('template_url') . '/images/triangle.png" class="tri hidden-xs" />';
        $data .= '</div>';
        $data .= '</div>';

        /*$parentCatId = $popularCat->term_id;
        $popularSubCats = $wpdb->get_results("select t.* from $wpdb->terms t join $wpdb->term_taxonomy tt where tt.term_id = t.term_id and tt.taxonomy = 'product_cat' and tt.parent = $parentCatId and t.is_popular = true order by t.name asc limit 5");
        $popularSubCatsCount = count($popularSubCats);
        $index = 0;
        foreach ($popularSubCats as $popularSubCat):
            $index++;
            $subCatObject = get_term_by("id", $popularSubCat->term_id, "product_cat");

            $data .= '<div class="';
            if ($index == $popularSubCatsCount): $data .='col-sm-2 col-xs-2 course lastElement relative';
            else: $data.='col-sm-2 col-xs-2 course';
            endif;
            $data.='">';
            $data .= '<a href="' . get_category_link($subCatObject) . '">' . $popularSubCat->name . '</a>';
            if ($index == $popularSubCatsCount):
                $data .= '<a href="' . get_category_link($catObject) . '" class="more hidden-xs"><i class="fa fa-chevron-circle-right"></i></a>';
            endif;
            $data .= '</div>';

        endforeach;
        */
        //get popular exams
                            $exams = new WP_Query(array(
                                'posts_per_page' => 5,
                                'post_type' => 'product',
                                'meta_key' => 'is_popular',
                                'meta_value' => '1',
                                'tax_query' => array(
                                    array(
                                        'taxonomy' => 'product_cat',
                                        'field' => 'slug',
                                        'terms' => $popularCat->slug
                                    )
                                )
                            ));
                            $examsCount = count($exams->get_posts());
                            $index = 0;
                            while ($exams->have_posts()):$exams->the_post();
                            $index++;
                            $data .= '<div class="';
                            if($index == $examsCount) $data.= 'col-sm-2 col-xs-2 course lastElement relative';
                            else $data.= 'col-sm-2 col-xs-2 course';
                            $data .= '"><a href="'.get_permalink().'">'.get_the_title().'</a>';
                            if($index == $examsCount) $data .= '<a href="'.get_permalink().'" class="more hidden-xs"><i class="fa fa-chevron-circle-right"></i></a>';
                            $data .= '</div>';

                            endwhile;
                            wp_reset_query();


        $data .= '<div class="col-sm-2 col-xs-2 course visible-xs">';
        $data .= '<a href="' . get_category_link($catObject) . '" class="more"><i class="fa fa-chevron-circle-right"></i></a>';
        $data .= '</div>';
        $data .= '</div>';
    endforeach;

    $data .= '</div>';
    $data .= '<div class="tab-pane" id="tc">';

    //get top certificat cat
    $topCertificatCats = $wpdb->get_results("select t.* from $wpdb->terms t join $wpdb->term_taxonomy tt where tt.term_id = t.term_id and tt.taxonomy = 'product_cat' and tt.parent <> 0 and t.is_top_certificat = true order by t.name asc limit 24");
    $topCertificatCatsCount = count($topCertificatCats);
    $index = 0;
    foreach ($topCertificatCats as $topCertificatCat):
        $topCertificatCatObject = get_term_by('id', $topCertificatCat->term_id, 'product_cat');
        if ($index % 6 == 0):

            $data .= '<div class="row examsRow zeroMargin">';
        endif;
        $data .= '<div class="col-sm-2 col-xs-2 course">';
        $data .= '<a href="' . get_category_link($topCertificatCatObject) . '">' . $topCertificatCat->name . '</a>';
        $data .= '</div>';

        $index++;
        if ($index == $topCertificatCatsCount || $index % 6 == 0):

            $data .= '</div>';

        endif;
    endforeach;

    $data .= '</div>';
    $data .= '<div class="tab-pane" id="re">';

    //get last updated products
    $latestUpdatedExams = new WP_Query(array(
        'posts_per_page' => 24,
        'post_type' => 'product',
        'orderby' => 'modified',
        'order' => 'desc'
    ));
    $latestUpdatedExamsCount = count($latestUpdatedExams->get_posts());
    $index = 0;
    while ($latestUpdatedExams->have_posts()):$latestUpdatedExams->the_post();
        if ($index % 6 == 0):

            $data .= '<div class="row examsRow zeroMargin">';
        endif;
        $data .= '<div class="col-sm-2 col-xs-2 course">';
        $data .= '<a href="' . get_permalink() . '">' . get_the_title() . '</a>';
        $data .= '</div>';

        $index++;
        if ($index == $latestUpdatedExamsCount || $index % 6 == 0):

            $data .= '</div>';

        endif;
    endwhile;
    wp_reset_query();

    $data .= '</div>';
    $data .= '<div class="tab-pane" id="ne">';

    //get last updated products
    $latestExams = new WP_Query(array(
        'posts_per_page' => 24,
        'post_type' => 'product'
    ));
    $latestExamsCount = count($latestExams->get_posts());
    $index = 0;
    while ($latestExams->have_posts()):$latestExams->the_post();
        if ($index % 6 == 0):

            $data .= '<div class="row examsRow zeroMargin">';
        endif;
        $data .= '<div class="col-sm-2 col-xs-2 course">';
        $data .= '<a href="' . get_permalink() . '">' . get_the_title() . '</a>';
        $data .= '</div>';

        $index++;
        if ($index == $latestExamsCount || $index % 6 == 0):

            $data .= '</div>';

        endif;
    endwhile;
    wp_reset_query();

    $data .= '</div>';
    $data .= '</div>';
    $data .= '</div>';
    $data .= '</div>';
    return $data;
}

add_shortcode('recent_exams', 'recent_exam_func');

/**
 * change menu wrap
 */
class Top_Category_Walker extends Walker_Nav_Menu {

    function start_el( &$output, $item, $depth = 0, $args = array(), $id = 0 ) {
        $classes = empty($item->classes) ? array() : (array) $item->classes;
        $class_names = join(' ', apply_filters('nav_menu_css_class', array_filter($classes), $item));
        !empty($class_names) and $class_names = ' class=" ' . esc_attr($class_names) . '"';
        $output .= "<div id='menu-item-$item->ID' $class_names>";
        $attributes = '';
        !empty($item->attr_title) and $attributes .= ' title="' . esc_attr($item->attr_title) . '"';
        !empty($item->target) and $attributes .= ' target="' . esc_attr($item->target) . '"';
        !empty($item->xfn) and $attributes .= ' rel="' . esc_attr($item->xfn) . '"';
        !empty($item->url) and $attributes .= ' href="' . esc_attr($item->url) . '"';
        $title = apply_filters('the_title', $item->title, $item->ID);
        $item_output = $args->before
                . "<a $attributes>"
                . $args->link_before
                . $title
                . '</a></div>'
                . $args->link_after
                . $args->after;
        $output .= apply_filters('walker_nav_menu_start_el', $item_output, $item, $depth, $args);
    }

}

class Top_Category_Walker2 extends Walker_Nav_Menu {

    function start_el( &$output, $item, $depth = 0, $args = array(), $id = 0 ) {
        $classes = empty($item->classes) ? array() : (array) $item->classes;
        $class_names = join(' ', apply_filters('nav_menu_css_class', array_filter($classes), $item));
        !empty($class_names) and $class_names = ' class="col-xs-1 ' . esc_attr($class_names) . '"';
        $output .= "<option value='" . esc_attr($item->url) . "'>";
        $attributes = '';
        !empty($item->attr_title) and $attributes .= ' title="' . esc_attr($item->attr_title) . '"';
        !empty($item->target) and $attributes .= ' target="' . esc_attr($item->target) . '"';
        !empty($item->xfn) and $attributes .= ' rel="' . esc_attr($item->xfn) . '"';
        !empty($item->url) and $attributes .= ' href="' . esc_attr($item->url) . '"';
        $title = apply_filters('the_title', $item->title, $item->ID);
        $item_output = $args->before
                . $args->link_before
                . $title
                . '</option>'
                . $args->link_after
                . $args->after;
        $output .= apply_filters('walker_nav_menu_start_el', $item_output, $item, $depth, $args);
    }

}

add_action("woocommerce_order_status_changed", "change_order_proccessing_completed", 10, 3);

function change_order_proccessing_completed($order_id, $status, $newStatus) {
    $order = new WC_Order($order_id);
    $orderStatus = $order->status;
    if ($newStatus == 'processing') {
        $new_status = get_term_by('slug', 'completed', 'shop_order_status');
        wp_set_object_terms($order_id, array($new_status->slug), 'shop_order_status', false);
    }
}


