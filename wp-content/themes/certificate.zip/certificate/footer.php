		<div class="inner">
			<div class="arguments">
				<div class="arg money-back">
					<?php
			        $moneyBackGuarantee = get_page_by_path('money-back-guarantee');
			        if ($moneyBackGuarantee):
			            ?>
			            <h4><?php echo $moneyBackGuarantee->post_title; ?></h4>
						<div class="arguments-logo hand"></div>
						<p><?php echo $moneyBackGuarantee->post_excerpt; ?></p>
			        <?php endif; ?>
					
				</div>
				<div class="arg customer-support">
					<?php
			        $excellentCustomerSupport = get_page_by_path('excellent-customer-support');
			        if ($excellentCustomerSupport):
			            ?>
						<h4><?php echo $excellentCustomerSupport->post_title; ?></h4>
						<div class="arguments-logo chat"></div>
						<p><?php echo $excellentCustomerSupport->post_excerpt; ?></p>
			        <?php endif; ?>			        
				</div>
				<div class="arg security-and-privacy">
					<?php
			        $securityPrivacy = get_page_by_path('security-privacy');
			        if ($securityPrivacy):
			            ?>
						<h4><?php echo $securityPrivacy->post_title; ?></h4>
						<div class="arguments-logo home"></div>
						<p><?php echo $securityPrivacy->post_excerpt; ?></p>
			        <?php endif; ?>
				</div>
				<div class="clr"></div>
			</div>
		</div>
		<div class="clr"></div>
		<div class="testimon-search">
			<div class="inner">
				<div class="testimonials">
					<h5>Testimonials</h5>
					<?php
		            $testimonials = new WP_Query(array(
		                'posts_per_page' => 1,
		                'post_type' => 'testimonial',
		                'meta_key' => 'is_video',
		                'meta_value' => '0'
		            ));
		            //check if vendor page
		            if (is_tax('product_cat')) {
		                $vendorSlug = get_query_var('term');
		
		                $args = array(
		                    'posts_per_page' => 1,
		                    'post_type' => 'testimonial',
		                    'meta_key' => 'is_video',
		                    'meta_value' => '0',
		                    'tax_query' => array(
		                        array(
		                            'taxonomy' => 'product_cat',
		                            'field' => 'slug',
		                            'terms' => $vendorSlug
		                        )
		                    )
		                );
		                $testimonials = new WP_Query($args);
		                if (!$testimonials->have_posts()) {
		                    $testimonials = new WP_Query(array(
		                        'posts_per_page' => 1,
		                        'post_type' => 'testimonial',
		                        'meta_key' => 'is_video',
		                        'meta_value' => '0'
		                    ));
		                }
		            }
		
		            if ($testimonials->have_posts()):
		                $index = 0;
		                while ($testimonials->have_posts()):$testimonials->the_post();
		
		                       
		                        // Remove html tags
		                        $content = strip_tags(trim(get_the_content()));
		                        // Check if the string is still too tall
		                        $length = 90;
		                        if (strlen($content) > $length) {
		                            // Remove 3 characters for the last 3 dots
		                            $length -= 3;
		                            $firstSpacePosition = strrpos(substr($content, 0, $length), ' ');
		                            if ($firstSpacePosition !== false) {
		                                $content = substr($content, 0, $firstSpacePosition);
		                            } else {
		                                $content = substr($content, 0, $length);
		                            }
		                            $content .= '...';
		                        }
		                        ?>
								<h6>"<?= $content ?>”</h6>
								<p><?php the_title(); ?></p>
		                    <?php
		                    $index++;
		                endwhile;
		                wp_reset_query();
		                ?>
		            <?php endif; ?>
					
									</div>
				<div class="footer-search">
					<h5>Search</h5>
					<form method="get" action="<?php echo get_page_link(get_post_using_slug('search-exams')); ?>" onsubmit="if(this.s.value == '' || this.s.value == 'Enter Exam Code ...'){ alert('Kindly type something in Search field');return false;}">
						<div id="footer_search">
							<input type="text" name="word" placeholder="Enter Exam Code">
							<input type="submit" name="submit" value="" id="footeR_search_button"/>
						</div>
					</form>
				</div>
			</div>
			<div class="clr"></div>
		</div>
		<div class="clr"></div>
		<div class="footer-menu menu">
			<div class="inner">
				<div class="bottom-menu">
					<ul>
						<li><a href="<?php echo home_url(); ?>/">Home</a></li>
						<li><a href="<?php echo home_url(); ?>/money-back-guarantee/">Money Back Guarantee</a></li>
						<li><a href="<?php echo home_url(); ?>/about-us/">About Us</a></li>
						<li><a href="<?php echo home_url(); ?>/faqs/">FAQS</a></li>
						<li><a href="<?php echo home_url(); ?>/disclaimer/">Disclaimer</a></li>
						<li><a href="<?php echo home_url(); ?>/my-account/">My Account</a></li>
						<li><a href="<?php echo home_url(); ?>/security-privacy/">Security & Privacy</a></li>
						<li><a href="<?php echo home_url(); ?>/contact-us/">Contact Us</a></li>
						
					</ul>
				</div>
			</div>
		</div>
		<div class="clr"></div>
		<div class="footer">
			<div class="inner">
<p><img src="/wp-content/themes/certificate/images/mcafee.jpg" alt="MCAfee"align="right"></p>

				<h2>We Accept:</h2>
<b> All Credit Cards , Visa , Master Card and others</a>
				
				<h6 id="copyright">A subsidiary of MUZ Enterprize .All Rights Reserved 2020</h6>
			</div>
			<div class="clr"></div>
		</div>
<?php wp_footer(); ?>
</body>
</html>
