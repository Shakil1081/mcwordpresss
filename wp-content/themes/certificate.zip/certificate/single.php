<?php
get_header();
the_post();
?>
    <div class="inner">
        <ol class="breadcrumb">
            <li><a href="<?php echo home_url(); ?>">Home</a></li>
            <li>></li>
            <li class="active"><?php the_title(); ?></li>
        </ol>
    </div>

    <div class="inner mainParas">
        <div class="col-xs-12 mp">
            <?php
            if ((function_exists('has_post_thumbnail')) && (has_post_thumbnail())):
                $image_id = get_post_thumbnail_id();
                $image_url = wp_get_attachment_image_src($image_id, 'full');
                $image_url = $image_url[0];
                $blogurl = get_bloginfo('url');
                $image_url = str_replace($blogurl, '', $image_url);
                ?>
                <img class="p-image" src="<?php bloginfo('template_url'); ?>/timthumb.php?src=<?php echo $image_url; ?>&amp;w=640&amp;h=180&amp;zc=1&amp;q=80" alt="<?php the_title(); ?>" style="width:100%;margin:0;"/>                
                <?php
            endif;
            the_content();
            ?>   
        </div>

    </div>
    <?php get_footer(); ?>