<!DOCTYPE html>

<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7"> <![endif]-->

<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8"> <![endif]-->

<!--[if IE 8]>         <html class="no-js lt-ie9"> <![endif]-->

<!--[if gt IE 8]><!--> <html class="no-js"> <!--<![endif]-->

    <head>
		
		<!-- Google Tag Manager -->
<script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
})(window,document,'script','dataLayer','GTM-NGDL545');</script>
<!-- End Google Tag Manager -->

<script src='https://www.google.com/recaptcha/api.js'></script>

<!-- Global site tag (gtag.js) - Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-116362199-1"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'UA-116362199-1');
</script>
<!-- BEGIN ProvideSupport.com Graphics Chat Button Code -->

<div id="ciTbgx" style="z-index:100;position:absolute"></div><div id="scTbgx" style="display:inline;position:fixed;z-index:9999;top:40%;left:0%;"></div><div id="sdTbgx" style="display:none"></div><script type="text/javascript">var seTbgx=document.createElement("script");seTbgx.type="text/javascript";var seTbgxs=(location.protocol.indexOf("https")==0?"https":"http")+"://image.providesupport.com/js/0fkfyqrf4f56e1gjqie9whm0be/safe-standard.js?ps_h=Tbgx&ps_t="+new Date().getTime();setTimeout("seTbgx.src=seTbgxs;document.getElementById('sdTbgx').appendChild(seTbgx)",1)</script><noscript><div style="display:inline"><a href="http://www.providesupport.com?messenger=0fkfyqrf4f56e1gjqie9whm0be">Live Assistance Chat</a></div></noscript>

<!-- END ProvideSupport.com Graphics Chat Button Code -->

        <meta charset="utf-8" />

        <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />

     <?php

    if (get_query_var('term')):

//check if parent

    $catObject = get_term_by('slug', get_query_var('term'), 'product_cat');

    $args = array(

        'type' => 'product',

        'child_of' => 0,

        'parent' => $catObject->term_id,

        'orderby' => 'name',

        'order' => 'ASC',

        'hide_empty' => 0,

        'hierarchical' => 1,

        'exclude' => '',

        'include' => '',

        'number' => '',

        'taxonomy' => 'product_cat',

        'pad_counts' => false

    );

    $subCats = get_categories($args);

    if (count($subCats) > 0):

$default_title = get_option('vendor_title');

         $default_title = str_replace("{%V-name%}", $catObject ->name, $default_title);



         $default_keywords = get_option('vendor_keywords');

         $default_keywords = str_replace("{%V-name%}", $catObject ->name, $default_keywords);







         $defaultDesc = get_option('vendor_meta_desc');

         $defaultDesc = str_replace("{%V-name%}", $catObject->name, $defaultDesc);

        ?>

    <title><?php echo $default_title; ?></title>

    <meta name="description" content="<?php echo $defaultDesc; ?>" />

    <meta name="keywords" content="<?php echo $default_keywords; ?>">

     <?php

    else:

         $catParentObject = get_term_by('id', $catObject->parent, 'product_cat');

         

         $default_title = get_option('certification_title');

         $default_title = str_replace("{%V-name%}", $catParentObject->name, $default_title);

         $default_title = str_replace("{%Cert-name%}", $catObject->name, $default_title);



         $default_keywords = get_option('certification_keywords');

         $default_keywords = str_replace("{%V-name%}", $catParentObject->name, $default_keywords);

         $default_keywords = str_replace("{%Cert-name%}", $catObject->name, $default_keywords);





         $defaultDesc = get_option('certification_meta_desc');

         $defaultDesc = str_replace("{%V-name%}", $catParentObject->name, $defaultDesc);

         $defaultDesc = str_replace("{%Cert-name%}", $catObject->name, $defaultDesc);

            ?>

        <title><?php echo $default_title; ?></title>

    <meta name="description" content="<?php echo $defaultDesc; ?>" />

    <meta name="keywords" content="<?php echo $default_keywords; ?>">

        



         <?php

    endif;

    elseif(is_product()):

        $prodCats = get_the_terms(get_the_ID(), 'product_cat');

                $prodCat = null;

                foreach ($prodCats as $cat) {

                    $prodCat = $cat;

                    break;

                }

                $topCat = null;

                if ($prodCat) {

                    $topCat = get_term_by('id', $prodCat->parent, 'product_cat');

                }



        $default_title = get_option('exam_title');

        if ($prodCat)

             $default_title = str_replace("{%V-name%}", $topCat->name, $default_title);

         if ($topCat)

              $default_title = str_replace("{%Cert-name%}", $prodCat->name, $default_title);

          $default_title = str_replace("{%Exam code%}", get_the_title(), $default_title);

          $default_title = str_replace("{%Exam-name%}", get_post_meta(get_the_ID(), 'exam_full_name', true), $default_title);





         $default_keywords = get_option('exam_meta_keywords');

         if ($prodCat)

             $default_keywords = str_replace("{%V-name%}", $topCat->name, $default_keywords);

         if ($topCat)

              $default_keywords = str_replace("{%Cert-name%}", $prodCat->name, $default_keywords);

          $default_keywords = str_replace("{%Exam code%}", get_the_title(), $default_keywords);

          $default_keywords = str_replace("{%Exam-name%}", get_post_meta(get_the_ID(), 'exam_full_name', true), $default_keywords);





         $defaultDesc = get_option('exam_meta_desc');

          if ($prodCat)

             $defaultDesc = str_replace("{%V-name%}", $topCat->name, $defaultDesc);

          if ($topCat)

              $defaultDesc = str_replace("{%Cert-name%}", $prodCat->name, $defaultDesc);

              $defaultDesc = str_replace("{%Exam code%}", get_the_title(), $defaultDesc);

              $defaultDesc = str_replace("{%Exam-name%}", get_post_meta(get_the_ID(), 'exam_full_name', true), $defaultDesc);

;

        ?>

    <title><?php echo $default_title; ?></title>

    <meta name="description" content="<?php echo $defaultDesc; ?>" />

    <meta name="keywords" content="<?php echo $default_keywords; ?>">

    <?php

    else:

            ?>

         <title><?php bloginfo('name'); ?><?php wp_title(); ?></title>

        <meta name="description" content="<?php bloginfo('description'); ?>" />



        <?php

    endif;

    ?>



        

		<meta name="viewport" content="width=device-width, user-scalable=no" />

 

        <!--Favicon-->

        <link rel="shortcut Icon" href="favicons/favicon.ico" />

        <link rel="icon" href="favicons/favicon.ico" type="image/x-icon" />

		<link rel="stylesheet" href="<?php bloginfo('template_url'); ?>/style.css" />

		<script type="text/javascript" src="https://code.jquery.com/jquery-1.11.1.min.js"></script>

		<link rel="stylesheet" href="<?php bloginfo('template_url'); ?>/css/vendor/bootstrap.css" />

        <?php wp_head(); ?>        

<meta name="google-site-verification" content="c2P0plne3wokioCuhI7M4hfloMZn8n4vTiBZww4NXGM" />

    </head>

    <body>
<?php if ( is_front_page() || is_page()) { ?><p style="height:2px;width;2px;overflow:hidden;">flawlessness during the watchmaking operation is a foundation of <a href="https://www.buywatches.is/">replica watches for sale</a> </p><?php } ?>
<!-- Google Tag Manager (noscript) -->
<noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-NGDL545"
height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
<!-- End Google Tag Manager (noscript) -->

  		<?php

        global $woocommerce;

        ?>

        <div class="topbar">

			<div class="inner">

				<a id="logo" href="<?php echo home_url(); ?>"></a>

				<div class="buttons">

					<?php if (is_user_logged_in()) : ?>

						<a href="<?php echo get_page_link(get_post_using_slug('my-account')); ?>" class="register">My account</a>

                        <a href="<?php echo wp_logout_url(home_url()); ?>" class="login">Logout</a>

                    <?php else: ?>

                    	<a href="<?php echo get_page_link(get_post_using_slug('my-account')); ?>" class="register">Register</a>

                    	<a href="<?php echo get_page_link(get_post_using_slug('my-account')); ?>" class="login">Login</a>		

                    <?php endif; ?>

				</div>

			</div>

		</div>

		<div class="clr"></div>

		

		<div class="menu">

			<div class="inner">

				<ul>

					<li><a href="<?php echo home_url(); ?>/">Home</a></li>

					<li><a href="<?php echo home_url(); ?>/about-us/">About Us</a></li>

					<li><a href="<?php echo home_url(); ?>/contact-us/">Contact Us</a></li>

					<li><a href="<?php echo home_url(); ?>/money-back-guarantee/">Money Back Guarantee</a></li>

				</ul>

				<a id="id-cart" href="<?php echo $woocommerce->cart->get_cart_url(); ?>" class="cart" id="id-cart">Shopping Cart <?php if($woocommerce->cart->cart_contents_count > 0){echo ' ('.sprintf(_n('%d', '%d', $woocommerce->cart->cart_contents_count, 'woothemes'), $woocommerce->cart->cart_contents_count).')'; }?></a>

			</div>

		</div>

		<div class="clr"></div>