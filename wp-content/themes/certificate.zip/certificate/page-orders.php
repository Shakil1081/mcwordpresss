<?php
if (!is_user_logged_in()) {
    wp_redirect(home_url());
}
get_header();
?>
    <div class="clr"></div>
    <div class="bg vendor-bg">
    	<form method="get" action="<?php echo get_page_link(get_post_using_slug('search-exams')); ?>" onsubmit="if(this.s.value == '' || this.s.value == 'Enter Exam Code ...'){ alert('Kindly type something in Search field');return false;}">
    	
			<div id="top_search">
					<input type="text" name="word" placeholder="Enter Exam Code"/>
					<input type="submit" name="submit" value="" id="top_search_button"/>
				</div>
    	</form>
    	</div>
	</div>
    <div class="inner">
    	<br/>
        <ol class="breadcrumb">
            <li><a href="<?php echo home_url(); ?>">Home</a></li> 
            <li class="del">></li>           
            <li class="active">Customer Orders</li>
        </ol>
        <div class="clr"></div>
    </div>
    <div class="inner mainParas zeroMarginTop zeroPaddingTop">
        <div class="account_menu_s col-md-3 col-sm-4 col-xs-12 mp">
            <h2 class="pull-left">Members Area</h2>
            <div class="clear"></div>
            <div class="tab-content popularCerts">
                <div class="tab-pane active" id="ci">
                    <?php include(TEMPLATEPATH . '/membersAreaLinks.php'); ?>
                </div>
            </div>
        </div>
        <div class="col-md-9 col-sm-8 col-xs-12 mp">
            <h2>Customer Orders</h2>
            <?php
            //get user orders
            if (is_user_logged_in()) :
                $currentUser = wp_get_current_user();
                /*
                $customer_orders = get_posts(apply_filters('woocommerce_my_account_my_orders_query', array(
                    'numberposts' => -1,
                    'meta_key' => '_customer_user',
                    'meta_value' => get_current_user_id(),
                    'post_type' => 'shop_order',
                    'post_status' => 'publish',
                    'tax_query' => array(
                        array(
                            'taxonomy' => 'shop_order_status',
                            'field' => 'slug',
                            'terms' => 'completed'
                        )
                    )
                )));*/

                $customer_orders = get_posts( array(
                    'numberposts' => -1,
                    'meta_key'    => '_customer_user',
                    'meta_value'  => get_current_user_id(),
                    'post_type'   => wc_get_order_types(),
                    'post_status' => 'wc-completed',
                ) );
                if ($customer_orders) :
                    ?>
                    <table class="footable table" data-sort="false">
                        <thead>
                            <tr>
                                <th>
                                    Order#
                                </th>
                                <th>
                                    Order Date
                                </th>
                                <th data-hide="phone">
                                    Exam Code
                                </th>
                                <th>
                                    Item Name
                                </th>
                                <th data-hide="phone">
                                    Expired Date
                                </th>
                                <th data-hide="phone">
                                    Download
                                </th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            foreach ($customer_orders as $customer_order):
                                $order = new WC_Order();
                                $order->populate($customer_order);
                                $items = $order->get_items();
                                foreach ($items as $item):
                                    ?>
                                    <tr>
                                        <td>
                                            <?php echo $order->get_order_number(); ?>
                                        </td>
                                        <td>
                                            <?php echo date('M d, Y', strtotime($order->order_date)); ?>
                                        </td>
                                        <td>
                                            <?php echo $item['name']; ?>
                                        </td>
                                        <td>
                                            <?php echo get_post_meta($item['product_id'], 'exam_full_name', true); ?>
                                        </td>
                                        <td>
                                            <?php
                                            $expireDate = new DateTime($order->order_date);
                                            $expireDate = $expireDate->modify('+' . get_option('exam_download_time', 90) . ' day');
                                            echo $expireDate->format('M d, Y');
                                            ?>
                                        </td>
                                        <td>
                                            <?php if ($expireDate > new DateTime()): ?>
                                                <a target="_blank" href="<?php echo get_bloginfo('template_url') . '/downloadExam.php/?orderId=' . $customer_order->ID . '&examId=' . $item['product_id']; ?>">Download</a>
                                            <?php else: ?>
                                                <a href="javascript:void(0)">Expired</a>
                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                    <?php
                                endforeach;
                            endforeach;
                            ?>
                        </tbody>
                    </table>
                <?php else: ?>
                    <div class="alert alert-danger">No orders found.</div>
                <?php
                endif;
            endif;
            ?>
            <div class="clr"></div>
           
        </div>
         <div class="clr"></div>
    </div>
    <script>
        $ = jQuery;
        $(document).ready(function() {
            $('.oHistory').addClass('active');
        });
    </script>
    <?php get_footer(); ?>