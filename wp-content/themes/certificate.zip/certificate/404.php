<?php
get_header();
the_post();
?>
<div class="container pageContent">
    <div class="row">
        <ol class="breadcrumb">
            <li><a href="<?php echo home_url(); ?>">Home</a></li>
            <li class="active"><?php the_title(); ?></li>
        </ol>
    </div>


    <div class="row mainParas">
        <div class="col-xs-12 mp">
           <h2><span class="glyphicon glyphicon-warning-sign"></span> Please contact 24/7 Live Chat Support if you are seeing this error page or email us here sales@examsboost.com</h2>
        </div>

    </div>
    <?php get_footer(); ?>